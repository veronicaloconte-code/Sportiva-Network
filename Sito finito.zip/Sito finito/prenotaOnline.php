<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

if (!isset($_SESSION['utente_loggato']) || $_SESSION['ruolo'] !== 'utente') {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "sportiva_network");
$idUtente = $_SESSION['idUtente'] ?? 0;
$successo = "";
$errore = "";

    $utente_loggato = isset($_SESSION['utente_loggato']);
    $nomeCompleto = "Utente";

    if ($utente_loggato) {
        $email = $_SESSION['utente_loggato'];
        $queryUtente = "SELECT nomeUtente, cognomeUtente FROM utenti WHERE emailUtente = '$email'";
        $risultatoUtente = $conn->query($queryUtente);

        if ($risultatoUtente && $risultatoUtente->num_rows > 0) {
            $utente = $risultatoUtente->fetch_assoc();
            // Correzione dei nomi dei campi del database:
            $nomeCompleto = $utente['nomeUtente'] . " " . $utente['cognomeUtente'];
        }
    }

// PRENOTAZIONE
if (isset($_POST['prenota'])) {
    $idAttivita = intval($_POST['idAttivita']);
    $dataPrenotazione = $_POST['dataPrenotazione'];

    $check = "SELECT idPrenotazione FROM prenotazioni 
              WHERE idUtente = $idUtente 
              AND dataPrenotazione = '$dataPrenotazione' 
              AND statoPrenotazione != 'Cancellata'";
    
    if ($conn->query($check)->num_rows > 0) {
        $errore = "Hai già una prenotazione per questa data!";
    } else {
        $insert = "INSERT INTO prenotazioni 
                  (nomePrenotazione, dataPrenotazione, oraPrenotazione, statoPrenotazione, presenzaUtente, idAttivita, idUtente) 
                  VALUES ('Prenotazione Attività', '$dataPrenotazione', NOW(), 'Confermata', 0, $idAttivita, $idUtente)";
        
        if ($conn->query($insert)) {
            $successo = "Prenotazione effettuata con successo!";
        } else {
            $errore = "Errore durante la prenotazione.";
        }
    }
}

// CANCELLAZIONE
if (isset($_POST['cancella_prenotazione'])) {
    $idPrenotazione = intval($_POST['idPrenotazione']);
    $delete = "UPDATE prenotazioni SET statoPrenotazione = 'Cancellata' 
               WHERE idPrenotazione = $idPrenotazione AND idUtente = $idUtente";
    
    if ($conn->query($delete)) {
        $successo = "Prenotazione cancellata con successo!";
    }
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prenota Online - Sportiva Network</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="background">

    <header class="main-header">
        <nav class="navbar">
            <div class="logo-container">
                <a href="index.html"><img src="media/immagini/logo.png" alt="Logo" class="logo-img"></a>
            </div>
            <ul class="nav-menu">
                <?php if ($utente_loggato): ?>
                        <div>
                            <li class="nav-item"><a href="home page.php">Home</a></li>
                        </div>
                    <?php else: ?>
                        <li class="nav-item"><a href="index.html">Home</a></li>
                    <?php endif; ?>
                <li class="nav-item"><a href="AreaSport.php">Area Sport</a></li>
                <li class="nav-item"><a href="WellnessEHub.php">Wellness e Hub</a></li>
                <li class="nav-item"><a href="PalaFamily.php">PalaFamily</a></li>
                <li class="nav-item"><a href="BusinessECoworking.php">Business e Coworking</a></li>
                <li class="nav-item"><a href="offerte.php">Tariffe</a></li>
                <div class="user-dropdown">
                    <button type="button" id="dropdownBtn" class="dropdown-btn">
                        👤 <?php echo $nomeCompleto; ?>
                    </button>

                    <div id="dropdownMenu" class="dropdown-content">
                        <a href="login.php?logout=true">Logout</a>
                    </div>
                </div>
            </ul>
        </nav>
    </header>

    <header class="spaziatura"></header>

    <div class="container">
        <h1>Prenota un'Attività</h1>

        <?php if ($successo) echo "<p class='successo'>$successo</p>"; ?>
        <?php if ($errore) echo "<p class='errore'>$errore</p>"; ?>

        <form method="POST">
            <label><strong>Seleziona Attività:</strong></label>
            <select name="idAttivita" required>
                <option value="">-- Scegli un'attività --</option>
                <?php
                $attivitaResult = $conn->query("SELECT a.*, s.nomeStruttura FROM attivita a LEFT JOIN strutture s ON a.idStruttura = s.idStruttura");
                while ($row = $attivitaResult->fetch_assoc()):
                ?>
                    <option value="<?= $row['idAttivita'] ?>">
                        <?= htmlspecialchars($row['nomeAttivita']) ?> (<?= $row['oraInizio'] ?> - <?= $row['oraFine'] ?>)
                    </option>
                <?php endwhile; ?>
            </select>

            <label><strong>Data:</strong></label>
            <input type="date" name="dataPrenotazione" value="<?= date('Y-m-d') ?>" min="<?= date('Y-m-d') ?>" required>
            
            <button type="submit" name="prenota" class="registrazione">Prenota</button>
        </form>

        <hr>
        <h2>Le Mie Prenotazioni</h2>

        <?php
        $resultMie = $conn->query("SELECT p.idPrenotazione, p.dataPrenotazione, p.statoPrenotazione,
                                          a.nomeAttivita, a.oraInizio, a.oraFine, s.nomeStruttura 
                                   FROM prenotazioni p 
                                   JOIN attivita a ON p.idAttivita = a.idAttivita 
                                   LEFT JOIN strutture s ON a.idStruttura = s.idStruttura 
                                   WHERE p.idUtente = $idUtente 
                                   ORDER BY p.dataPrenotazione DESC");
        ?>

        <table border="1" cellpadding="10" style="width:100%; border-collapse:collapse;">
            <tr style="background:#0c4a8a; color:white;">
                <th>Attività</th><th>Data</th><th>Orario</th><th>Struttura</th><th>Stato</th><th>Azione</th>
            </tr>
            <?php if ($resultMie->num_rows > 0): ?>
                <?php while ($p = $resultMie->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($p['nomeAttivita']) ?></td>
                        <td><?= $p['dataPrenotazione'] ?></td>
                        <td><?= $p['oraInizio'] ?> - <?= $p['oraFine'] ?></td>
                        <td><?= htmlspecialchars($p['nomeStruttura'] ?? '-') ?></td>
                        <td><?= $p['statoPrenotazione'] ?></td>
                        <td>
                            <?php if ($p['statoPrenotazione'] != 'Cancellata'): ?>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('Cancellare?');">
                                    <input type="hidden" name="idPrenotazione" value="<?= $p['idPrenotazione'] ?>">
                                    <button type="submit" name="cancella_prenotazione" style="color:red;">Cancella</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="6">Nessuna prenotazione trovata.</td></tr>
            <?php endif; ?>
        </table>
    </div>

    <footer class="spaziatura"></footer>

    <footer>
        <div class="footer-container">
            <div class="footer-col">
                <div class="logo-container" style="margin-bottom: 20px;">
                    <a href="#">
                        <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                    </a>
                </div>
                <p class="generated-style-12">Il punto di incontro ideale per chi ama lo sport, valorizza il benessere, ottimizza il lavoro e protegge il tempo in famiglia.</p>
            </div>
            <div class="footer-col">
                <h4>I 4 Quadranti</h4>
                <ul>
                    <li><a href="VascaNuoto.php">Academy Nuoto</a></li>
                    <li><a href="PrenotaPadel.php">Padel e Tennis Eventi</a></li>
                    <li><a href="OrariPalestra.php">Preparazione Atletica</a></li>
                    <li><a href="IscriviSquadra.php">Scuola Calcio Giovani</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Lifestyle Servizi</h4>
                <ul>
                    <li><a href="#">Centro Medico ed Estetico</a></li>
                    <li><a href="#">Coworking & Startup Lab</a></li>
                    <li><a href="#">Ristorante & Lounge Bar</a></li>
                    <li><a href="#">Feste PalaFamily</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Contatti e Orari</h4>
                <p class="footer-p">Viale dello Sport, 100<br>10095 Grugliasco (TO)</p>
                <p class="footer-p">Segreteria: +39 011 555 7788<br>Email: info@sportivanetwork.com</p>
                <p class="footer-p1">Aperti tutti i giorni: 08:00 - 24:00</p>
            </div>
        </div>
        <div class="footer-bottom">
            <div>&copy; 2026 Sportiva Network S.r.l. | P.IVA 12345678901 | Tutti i diritti riservati.</div>
            <div><a href="#" class="footer-link">Privacy Policy</a> <a href="#" class="footer-link1">Safeguarding Policy</a></div>
        </div>
    </footer>
</body>
</html>