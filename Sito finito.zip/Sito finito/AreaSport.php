<?php
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "sportiva_network";
    $conn = new mysqli($host, $user, $password, $database);

    // Controlliamo se l'utente è loggato
    $utente_loggato = isset($_SESSION['utente_loggato']);
    $nomeCompleto = "Utente";

    if ($utente_loggato) {
        $email = $_SESSION['utente_loggato'];
        $queryUtente = "SELECT nomeUtente, cognomeUtente FROM utenti WHERE emailUtente = '$email'";
        $risultatoUtente = $conn->query($queryUtente);

        if ($risultatoUtente && $risultatoUtente->num_rows > 0) {
            $utente = $risultatoUtente->fetch_assoc();
            // Correzione dei nomi dei campi del database:
            $nomeCompleto = $utente['nomeUtente'] . " " . $utente['cognomeUtente'];
        }
    }
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Area Sport</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!--Barra ricerca in alto-->
        <header class="main-header">
            <nav class="navbar">
                <div class="logo-container">
                    <a href="#">
                        <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                    </a>
                </div>

                <ul class="nav-menu">
                    <?php if ($utente_loggato): ?>
                        <div>
                            <li class="nav-item"><a href="home page.php">Home</a></li>
                        </div>
                    <?php else: ?>
                        <li class="nav-item"><a href="index.html">Home</a></li>
                    <?php endif; ?>
                    <li class="nav-item"><a href="AreaSport.php">Area Sport</a></li>
                    <li class="nav-item"><a href="WellnessEHub.php">Wellness e Hub</a></li>
                    <li class="nav-item"><a href="PalaFamily.php">PalaFamily</a></li>
                    <li class="nav-item"><a href="BusinessECoworking.php">Business e Coworking</a></li>
                    <li class="nav-item"><a href="offerte.php">Tariffe</a></li>
                    <li class="nav-item"><a href="prenotaOnline.php" class="btn-prenota">Prenota Online</a></li>

                    <?php if ($utente_loggato): ?>
                        <div class="user-dropdown">
                            <button type="button" id="dropdownBtn" class="dropdown-btn">
                                👤 <?php echo htmlspecialchars($nomeCompleto); ?>
                            </button>
                            <div id="dropdownMenu" class="dropdown-content">
                                <a href="login.php?logout=true">Logout</a>
                            </div>
                        </div>
                    <?php else: ?>
                        <li class="nav-item"><a href="login.php" class="btn-accedi">Accedi</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </header>
        
        <script src="js/tendina-login.js"></script>

        <header class="hero">
        <div class="hero-container">
            <div class="hero-content">
                <h1>Il cuore del tuo <span>Allenamento</span></h1>
                <p class="hero-subtitle">Strutture di ultima generazione, istruttori federali e un ambiente progettato per tirare fuori il meglio di te. Scopri tutte le discipline della nostra Area Sport.</p>
            </div>
        </div>
        </header>

        <section class="sports-grid" style="margin-top: 40px; margin-bottom: 40px;">
            <div class="sport-card card-blue">
                <div class="sport-icon-box bg-blue"><img src="media/immagini/nuoto.png" alt="nuoto" class="nuoto"></div>
                <h3>Nuoto Libero & Corsi</h3>
                <p>Vasca semi-olimpionica a 6 corsie e vasca riscaldata per i più piccoli. Corsi di acquagym, hydrobike e lezioni private per perfezionare gli stili.</p>
                <br>
                <strong>Orari:</strong> Lun-Dom 08:00 - 22:30
            </div>

            <div class="sport-card card-green">
                <div class="sport-icon-box bg-green"><img src="media/immagini/tennis.png" alt="tennis" class="tennis"></div>
                <h3>Padel & Tennis Arena</h3>
                <p>Prenota il tuo campo tramite la nostra App. Organizziamo tornei settimanali, lezioni singole o di gruppo con maestri FITP certificati.</p>
                <br>
                <strong>Campi:</strong> 10 Indoor, 4 Outdoor
            </div>

            <div class="sport-card card-orange">
                <div class="sport-icon-box bg-orange"><img src="media/immagini/palestra.png" alt="fitnes" class="fitnes"></div>
                <h3>Sala Pesi & Corsi Fitness</h3>
                <p>Più di 40 corsi settimanali tra cui Pilates, Yoga, TRX e Cross Training. Sala pesi attrezzata Technogym con schede di allenamento personalizzate.</p>
                <br>
                <strong>Schede:</strong> Incluse nell'abbonamento
            </div>

            <div class="sport-card card-red">
                <div class="sport-icon-box bg-red"><img src="media/immagini/calcio.png" alt="calcio" class="calcio"></div>
                <h3>Calcio a 5</h3>
                <p>Campi in erba sintetica di ultima generazione. Ideale per la partita con gli amici o per i tornei aziendali. Spogliatoi privati e servizio pettorine.</p>
                <br>
                <strong>Novità:</strong> Telecamere per highlights
            </div>
        </section>


        <!--Recapiti-->
        <footer>
            <div class="footer-container">
                <div class="footer-col">
                    <div class="logo-container" style="margin-bottom: 20px;">
                        <a href="#">
                            <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                        </a>
                    </div>
                    <p class="generated-style-12">Il punto di incontro ideale per chi ama lo sport, valorizza il benessere, ottimizza il lavoro e protegge il tempo in famiglia.</p>
                </div>
                <div class="footer-col">
                    <h4>I 4 Quadranti</h4>
                    <ul>
                        <li><a href="VascaNuoto.php">Academy Nuoto</a></li>
                        <li><a href="PrenotaPadel.php">Padel e Tennis Eventi</a></li>
                        <li><a href="OrariPalestra.php">Preparazione Atletica</a></li>
                        <li><a href="IscriviSquadra.php">Scuola Calcio Giovani</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Lifestyle Servizi</h4>
                    <ul>
                        <li><a href="#">Centro Medico ed Estetico</a></li>
                        <li><a href="#">Coworking & Startup Lab</a></li>
                        <li><a href="#">Ristorante & Lounge Bar</a></li>
                        <li><a href="#">Feste PalaFamily</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Contatti e Orari</h4>
                    <p class="footer-p">Viale dello Sport, 100<br>10095 Grugliasco (TO)</p>
                    <p class="footer-p">Segreteria: +39 011 555 7788<br>Email: info@sportivanetwork.com</p>
                    <p class="footer-p1">Aperti tutti i giorni: 08:00 - 24:00</p>
                </div>
            </div>
            <div class="footer-bottom">
                <div>&copy; 2026 Sportiva Network S.r.l. | P.IVA 12345678901 | Tutti i diritti riservati.</div>
                <div><a href="#" class="footer-link">Privacy Policy</a> <a href="#" class="footer-link1">Safeguarding Policy</a></div>
            </div>
        </footer>
</body>
</html>