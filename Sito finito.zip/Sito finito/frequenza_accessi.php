<?php
    session_start();

    // Controllo se l'utente è loggato ed è un utente normale
    if (!isset($_SESSION['utente_loggato']) || $_SESSION['ruolo'] != "utente") {
        header("Location: login.php");
        exit();
    }

    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "sportiva_network";
    $conn = new mysqli($host, $user, $password, $database);

    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }

    $utente_loggato = isset($_SESSION['utente_loggato']);
    $nomeCompleto = "Utente";

    if ($utente_loggato) {
        $email = $_SESSION['utente_loggato'];
        $queryUtente = "SELECT nomeUtente, cognomeUtente FROM utenti WHERE emailUtente = '$email'";
        $risultatoUtente = $conn->query($queryUtente);

        if ($risultatoUtente && $risultatoUtente->num_rows > 0) {
            $utente = $risultatoUtente->fetch_assoc();
            // Correzione dei nomi dei campi del database:
            $nomeCompleto = $utente['nomeUtente'] . " " . $utente['cognomeUtente'];
        }
    }

    $idUtente = $_SESSION['idUtente'];

    // Query per contare i login raggruppati per giorno
    $queryFrequenza = "SELECT dataLogin, COUNT(*) as totaleLogin 
                       FROM log_accessi 
                       WHERE idUtente = '$idUtente' 
                       GROUP BY dataLogin 
                       ORDER BY dataLogin DESC";

    $risultato = $conn->query($queryFrequenza);
?>

<!DOCTYPE html>
<html lang="it">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Frequenza Accessi - Sportiva Network</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <header class="main-header">
            <nav class="navbar">
                <div class="logo-container">
                    <a href="area_utenti.php">
                        <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                    </a>
                </div>
                <ul class="nav-menu">
                    <?php if ($utente_loggato): ?>
                        <div>
                            <li class="nav-item"><a href="home page.php">Home</a></li>
                        </div>
                    <?php else: ?>
                        <li class="nav-item"><a href="index.html">Home</a></li>
                    <?php endif; ?>
                    <li class="nav-item"><a href="AreaSport.php">Area Sport</a></li>
                    <li class="nav-item"><a href="WellnessEHub.php">Wellness e Hub</a></li>
                    <li class="nav-item"><a href="PalaFamily.php">PalaFamily</a></li>
                    <li class="nav-item"><a href="BusinessECoworking.php">Business e Coworking</a></li>
                    <li class="nav-item"><a href="offerte.php">Tariffe</a></li>
                    <li class="nav-item"><a href="prenotaOnline.php" class="btn-prenota">Prenota Online</a></li>

                    <?php if ($utente_loggato): ?>
                        <div class="user-dropdown">
                            <button type="button" id="dropdownBtn" class="dropdown-btn">
                                👤 <?php echo htmlspecialchars($nomeCompleto); ?>
                            </button>
                            <div id="dropdownMenu" class="dropdown-content">
                                <a href="login.php?logout=true">Logout</a>
                            </div>
                        </div>
                    <?php else: ?>
                        <li class="nav-item"><a href="login.php" class="btn-accedi">Accedi</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </header>

        <header class="spaziatura"></header>

        <section class="pricing-section" style="padding: 40px 20px; min-height: 50vh;">
            <h2>Cronologia e Frequenza dei tuoi Accessi</h2>
            <p style="text-align: center; margin-bottom: 30px;">Qui puoi verificare quante volte ti sei loggato nel sito diviso per ciascun giorno.</p>
            
            <table class="info-table" style="max-width: 600px; margin: 0 auto;">
                <thead>
                    <tr>
                        <th>Giorno / Data</th>
                        <th>Numero di Login</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($risultato && $risultato->num_rows > 0) {
                        while ($riga = $risultato->fetch_assoc()) {
                            // Formattiamo la data in formato italiano (GG/MM/AAAA)
                            $dataFormattata = date("d/m/Y", strtotime($riga['dataLogin']));
                            echo "<tr>";
                            echo "<td><strong>" . $dataFormattata . "</strong></td>";
                            echo "<td>" . $riga['totaleLogin'] . " volte</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='2' style='text-align:center;'>Nessun dato di accesso registrato.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
            
            <div style="text-align: center; margin-top: 30px;">
                <a href="area_utenti.php" class="btn" style="display: inline-block; text-decoration: none; padding: 12px 24px; color: #ffffff; background-color: #1e293b; font-weight: bold;">&larr; Torna alla tua Area</a>
            </div>
        </section>

        <footer class="spaziatura"></footer>

        <footer>
            <div class="footer-container">
                <div class="footer-col">
                    <div class="logo-container" style="margin-bottom: 20px;">
                        <a href="#">
                            <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                        </a>
                    </div>
                    <p class="generated-style-12">Il punto di incontro ideale per chi ama lo sport, valorizza il benessere, ottimizza il lavoro e protegge il tempo in famiglia.</p>
                </div>
                <div class="footer-col">
                    <h4>I 4 Quadranti</h4>
                    <ul>
                        <li><a href="VascaNuoto.php">Academy Nuoto</a></li>
                        <li><a href="PrenotaPadel.php">Padel e Tennis Eventi</a></li>
                        <li><a href="OrariPalestra.php">Preparazione Atletica</a></li>
                        <li><a href="IscriviSquadra.php">Scuola Calcio Giovani</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Lifestyle Servizi</h4>
                    <ul>
                        <li><a href="#">Centro Medico ed Estetico</a></li>
                        <li><a href="#">Coworking & Startup Lab</a></li>
                        <li><a href="#">Ristorante & Lounge Bar</a></li>
                        <li><a href="#">Feste PalaFamily</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Contatti e Orari</h4>
                    <p class="footer-p">Viale dello Sport, 100<br>10095 Grugliasco (TO)</p>
                    <p class="footer-p">Segreteria: +39 011 555 7788<br>Email: info@sportivanetwork.com</p>
                    <p class="footer-p1">Aperti tutti i giorni: 08:00 - 24:00</p>
                </div>
            </div>
            <div class="footer-bottom">
                <div>&copy; 2026 Sportiva Network S.r.l. | P.IVA 12345678901 | Tutti i diritti riservati.</div>
                <div><a href="#" class="footer-link">Privacy Policy</a> <a href="#" class="footer-link1">Safeguarding Policy</a></div>
            </div>
        </footer>
    </body>
</html>