const tabs = document.querySelectorAll(".widget-tab");

tabs.forEach(tab => {

    tab.addEventListener("click", () => {

        tabs.forEach(t => {

            t.classList.remove("tab-active");

        });

        tab.classList.add("tab-active");

    });

});