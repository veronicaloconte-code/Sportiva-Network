document.addEventListener('DOMContentLoaded', function() {
    const btn = document.getElementById("dropdownBtn");
    const menu = document.getElementById("dropdownMenu");

    window.addEventListener("click", function () {
        menu.style.display = "none";
    });

    btn.addEventListener("click", function (e) {
        e.stopPropagation();

        if (menu.style.display === "block") {
            menu.style.display = "none";
        } else {
            menu.style.display = "block";
        }
    });

});