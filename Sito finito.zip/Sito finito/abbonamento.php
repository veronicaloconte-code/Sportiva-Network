<?php // Attiva l'interprete PHP sul server

    session_start(); // Avvia o riprende la sessione per gestire i dati dell'utente connesso

    /* CONTROLLO LOGIN */
    if(!isset($_SESSION['utente_loggato'])){ // Se la variabile di sessione del login non esiste...
        header("Location: login.php"); // Reindirizza forzatamente l'utente alla pagina di login
        exit(); // Interrompe immediatamente l'esecuzione del codice di questa pagina
    }

    /* CONNESSIONE DATABASE */
    $host = "localhost"; // Definisce l'indirizzo del server del database (locale)
    $user = "root"; // Definisce l'username di amministrazione del database
    $password = ""; // Definisce la password (vuota di default in locale)
    $database = "sportiva_network"; // Definisce il nome del database a cui connettersi

    $conn = mysqli_connect($host, $user, $password, $database); // Tenta la connessione al database MySQL

    if(!$conn){ // Se la connessione è fallita (restituisce false)...
        die("Errore connessione"); // Blocca lo script e mostra un messaggio di errore generico
    }

    // CONNESSIONE UTENTE
    $email = $_SESSION['utente_loggato']; // Recupera l'email dell'utente loggato dalla sessione
    $queryUtente = "SELECT nomeUtente, cognomeUtente FROM utenti WHERE emailUtente = '$email'"; // Prepara la query per prendere Nome e Cognome dell'utente
    $risultatoUtente = $conn->query($queryUtente); // Esegue la query appena preparata sul database

    if (!$risultatoUtente) { // Se la query ha un errore di sintassi o fallisce...
        die("Errore query: " . $conn->error); // Blocca lo script e mostra l'errore SQL dettagliato
    }

    if ($risultatoUtente->num_rows > 0) { // Se il database ha trovato almeno una riga corrispondente...
        $utente = $risultatoUtente->fetch_assoc(); // Estrae la riga trasformandola in un array associativo
        $nomeCompleto = $utente['nomeUtente'] . " " . $utente['cognomeUtente']; // Unisce il nome e il cognome in un'unica stringa
    } else { // Se non trova corrispondenze nel database...
        $nomeCompleto = "Utente"; // Assegna un nome predefinito di ripiego
    }

    /* ACQUISTO ABBONAMENTO / OFFERTA */

    if($_SERVER['REQUEST_METHOD'] == 'POST'){ // Se la pagina riceve dati inviati da un form (metodo POST)...

        // Recupera l'ID dell'utente dalla sessione se esiste, altrimenti imposta 0
        $idUtente = isset($_SESSION['idUtente']) ? $_SESSION['idUtente'] : 0;

        // Recupera il nome dell'abbonamento dal form e lo ripulisce da caratteri nocivi (SQL Injection)
        $nomeAbbonamento = isset($_POST['nomeAbbonamento']) ? mysqli_real_escape_string($conn, $_POST['nomeAbbonamento']) : '';
        // Recupera la categoria/tipo dell'abbonamento dal form e la ripulisce per sicurezza
        $tipoAbbonamento = isset($_POST['tipoAbbonamento']) ? mysqli_real_escape_string($conn, $_POST['tipoAbbonamento']) : '';

        // Controlla se l'ID dell'offerta è presente nel form e non è vuoto
        if (isset($_POST['idOfferta']) && !empty($_POST['idOfferta'])) {
            $idOfferta = intval($_POST['idOfferta']); // Converte l'ID in un numero intero sicuro
            $valoreOffertaSql = "'$idOfferta'"; // Prepara il valore per la query racchiuso tra apici
        } else {
            $valoreOffertaSql = "NULL"; // Se non c'è l'ID offerta, imposta la parola NULL per il database
        }

        // Se i campi obbligatori (nome e tipo) non sono vuoti, procede all'acquisto
        if (!empty($nomeAbbonamento) && !empty($tipoAbbonamento)) {

            // Prepara la query di inserimento per salvare l'abbonamento nel database
            $query = "
            INSERT INTO abbonamenti 
            (
                nomeAbbonamento,
                tipoAbbonamento,
                idUtente,
                idOfferta
            )
            VALUES
            (
                '$nomeAbbonamento',
                '$tipoAbbonamento',
                '$idUtente',
                $valoreOffertaSql
            )";

            if(mysqli_query($conn, $query)){ // Esegue la query di inserimento e controlla se va a buon fine
                $successo = "Abbonamento acquistato correttamente"; // Crea il messaggio di successo
            } else {
                $errore = "Errore inserimento: " . mysqli_error($conn); // Crea il messaggio di errore con il dettaglio SQL
            }
        } else {
            $errore = "I dati dell'abbonamento non sono validi o sono incompleti."; // Messaggio di errore se i campi erano vuoti
        }
    }

    /* VISUALIZZAZIONE OFFERTE (per la griglia in fondo alla pagina) */
    $query = "SELECT * FROM attivita"; // Prepara la query per selezionare tutte le attività disponibili
    $result = mysqli_query($conn, $query); // Esegue la query e salva la lista delle attività in $result

?> <!DOCTYPE html> <html lang="it"> <head>
        <meta charset="UTF-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0" > <title>Abbonamenti</title> <link rel="stylesheet" href="style.css"> </head>

    <body> <header class="main-header"> <nav class="navbar"> <div class="logo-container"> <a href="#"><img src="media/immagini/logo.png" class="logo-img" ></a> </div>

                <ul class="nav-menu"> <li class="nav-item"><a href="index.html">Home</a></li> <li class="nav-item"><a href="AreaSport.html">Area Sport</a></li> <li class="nav-item"><a href="WellnessEHub.html">Wellness e Hub</a></li> <li class="nav-item"><a href="PalaFamily.html">PalaFamily</a></li> <li class="nav-item"><a href="BusinessECoworking.html">Business e Coworking</a></li> <li class="nav-item"><a href="offerte.php">Tariffe</a></li> <li class="nav-item"><a href="prenotaOnline.php" class="btn-prenota">Prenota Online</a></li> <div class="user-dropdown"> <button type="button" id="dropdownBtn" class="dropdown-btn"> 👤 <?php echo $nomeCompleto; ?> </button>

                        <div id="dropdownMenu" class="dropdown-content"> <a href="login.php?logout=true">Logout</a> </div>
                    </div>
                </ul>
            </nav>
        </header>

        <section class="offerte-container"> <h1 class="offerte-titolo"> Acquista il tuo Abbonamento</h1> <?php

                if(isset($successo)){ // Se esiste la variabile del successo dell'acquisto...
                    echo "<p class='successo'>$successo</p>"; // Stampa a schermo il messaggio verde di successo
                }

                if(isset($errore)){ // Se esiste la variabile di errore...
                    echo "<p class='errore'>$errore</p>"; // Stampa a schermo il messaggio rosso di errore
                }

            ?>

            <div class="offerte-grid"> <?php

                    // Avvia un ciclo che si ripete per ogni attività estratta dal database
                    while($attivita = mysqli_fetch_assoc($result)){ 
                        $prezzo = rand(20,80); // Genera un prezzo finto casuale intero tra 20 e 80 euro
                        $sconto = rand(10,40); // Genera uno sconto finto casuale tra il 10% e il 40%
                        $prezzoScontato = $prezzo -($prezzo * $sconto / 100); // Calcola matematicamente il prezzo finale ridotto dello sconto

                        // Inizia a stampare il blocco di codice HTML per la singola scheda dell'attività
                        echo "
                        <div class='offerta-card'> <div class='offerta-header'> <div class='offerta-nome'>

                                    ".$attivita['nomeAttivita']." </div>

                                <div class='offerta-categoria'>

                                    ".$attivita['categoria']." </div>

                            </div>

                            <div class='offerta-body'> <div class='offerta-info'>

                                    ".$attivita['descrizione']." </div>

                                <div class='offerta-info'>

                                    ".$attivita['oraInizio']." - ".$attivita['oraFine']." </div>

                                <div class='offerta-prezzo'>

                                    € ".number_format($prezzoScontato, 2)." </div>

                                <div class='offerta-prezzo-originale'>

                                    € ".$prezzo." </div>

                                <div class='offerta-sconto'>

                                    -".$sconto."% </div>

                                <form action='abbonamento.php' method='POST'> <input type='hidden' name='idOfferta' value=''> <input type='hidden' name='nomeAbbonamento' value='".$attivita['nomeAttivita']."'> <input type='hidden' name='tipoAbbonamento' value='".$attivita['categoria']."'> <button type='submit' class='offerta-bottone'>Acquista Abbonamento</button> </form>

                            </div>

                        </div>

                        "; // Fine della stringa di output della singola scheda
                    } // Fine del ciclo while: torna su e controlla se ci sono altre attività nel database

                ?>

            </div>

        </section>

    </body>

</html>

<?php

    mysqli_close($conn); // Chiude formalmente la connessione con il database per liberare risorse sul server

?>