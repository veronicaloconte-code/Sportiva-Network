<?php
    session_start();

    if (!isset($_SESSION['utente_loggato']) || $_SESSION['ruolo'] !== 'utente') {
        header("Location: login.php");
        exit();
    }

    $conn = new mysqli("localhost", "root", "", "sportiva_network");
    $idUtente = $_SESSION['idUtente'] ?? 0;
    $successo = "";
    $errore = "";

    $utente_loggato = isset($_SESSION['utente_loggato']);
    $nomeCompleto = "Utente";

    if ($utente_loggato) {
        $email = $_SESSION['utente_loggato'];
        $queryUtente = "SELECT nomeUtente, cognomeUtente FROM utenti WHERE emailUtente = '$email'";
        $risultatoUtente = $conn->query($queryUtente);

        if ($risultatoUtente && $risultatoUtente->num_rows > 0) {
            $utente = $risultatoUtente->fetch_assoc();
            // Correzione dei nomi dei campi del database:
            $nomeCompleto = $utente['nomeUtente'] . " " . $utente['cognomeUtente'];
        }
    }

    /* Recupero ID utente dalla sessione */ 
    $idUtente = $_SESSION['idUtente']; 

    /* Query storico prenotazioni */ 
    $sql = "
    SELECT 
        prenotazioni.*,
        attivita.nomeAttivita,
        utenti.nomeUtente,
        utenti.cognomeUtente

    FROM prenotazioni

    LEFT JOIN attivita
        ON prenotazioni.idAttivita = attivita.idAttivita

    LEFT JOIN utenti
        ON prenotazioni.idUtente = utenti.idUtente

    WHERE prenotazioni.idUtente = '$idUtente'

    ORDER BY prenotazioni.dataPrenotazione DESC
    ";

    $res = $conn->query($sql);

    if(!$res){
        die('Errore SQL: ' . $conn->error);
    }
     
?>

<!DOCTYPE html> 
<html lang="it"> 
    <head> 
        <meta charset="UTF-8"> 
        <title>Storico Prenotazioni</title> 
        <link rel="stylesheet" href="style.css"> 
    </head> 
    <body> 
        <header class="main-header"> 
            <nav class="navbar"> 
                <div class="logo-container">
                    <a href="#">
                        <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                    </a>
                </div>

                <ul class="nav-menu">
                    <?php if ($utente_loggato): ?>
                        <div>
                            <li class="nav-item"><a href="home page.php">Home</a></li>
                        </div>
                    <?php else: ?>
                        <li class="nav-item"><a href="index.html">Home</a></li>
                    <?php endif; ?>
                    <li class="nav-item"><a href="AreaSport.php">Area Sport</a></li>
                    <li class="nav-item"><a href="WellnessEHub.php">Wellness e Hub</a></li>
                    <li class="nav-item"><a href="PalaFamily.php">PalaFamily</a></li>
                    <li class="nav-item"><a href="BusinessECoworking.php">Business e Coworking</a></li>
                    <li class="nav-item"><a href="offerte.php">Tariffe</a></li>
                    <div class="user-dropdown">
                        <button type="button" id="dropdownBtn" class="dropdown-btn">
                            👤 <?php echo $nomeCompleto; ?>
                        </button>

                        <div id="dropdownMenu" class="dropdown-content">
                            <a href="login.php?logout=true">Logout</a>
                        </div>
                    </div>  
                </ul>
            </nav> 
        </header> 
        
        <div class="container-fluid"> 
            <main class="col-md-9 col-lg-10 ms-sm-auto px-md-4 py-4"> 
                <h2>Storico Prenotazioni</h2> 
                <?php if(mysqli_num_rows($res) > 0): ?> 
                    <table class="table bg-white shadow-sm"> 
                        <thead>
                            <tr>
                                <th>Utente</th>
                                <th>Attività</th>
                                <th>Data</th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php while($row = $res->fetch_assoc()): ?>

                        <tr>
                            <td>
                                <?= $row['nomeUtente'] ?>
                                <?= $row['cognomeUtente'] ?>
                            </td>
                            <td>
                                <?= $row['nomeAttivita'] ?>
                            </td>
                            <td>
                                <?= $row['dataPrenotazione'] ?>
                            </td>
                        </tr>

                        <?php endwhile; ?>

                        </tbody>
                    </table> 
                    <?php else: ?> 
                    <div class="card p-3"> 
                        <p>Nessuna prenotazione trovata.</p> 
                    </div> 
                    <?php endif; ?> 
                </main> 
            </div> 
        <footer>
            <div class="footer-container">
                <div class="footer-col">
                    <div class="logo-container" style="margin-bottom: 20px;">
                        <a href="#">
                            <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                        </a>
                    </div>
                    <p class="generated-style-12">Il punto di incontro ideale per chi ama lo sport, valorizza il benessere, ottimizza il lavoro e protegge il tempo in famiglia.</p>
                </div>
                <div class="footer-col">
                    <h4>I 4 Quadranti</h4>
                    <ul>
                        <li><a href="VascaNuoto.php">Academy Nuoto</a></li>
                        <li><a href="PrenotaPadel.php">Padel e Tennis Eventi</a></li>
                        <li><a href="OrariPalestra.php">Preparazione Atletica</a></li>
                        <li><a href="IscriviSquadra.php">Scuola Calcio Giovani</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Lifestyle Servizi</h4>
                    <ul>
                        <li><a href="#">Centro Medico ed Estetico</a></li>
                        <li><a href="#">Coworking & Startup Lab</a></li>
                        <li><a href="#">Ristorante & Lounge Bar</a></li>
                        <li><a href="#">Feste PalaFamily</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Contatti e Orari</h4>
                    <p class="footer-p">Viale dello Sport, 100<br>10095 Grugliasco (TO)</p>
                    <p class="footer-p">Segreteria: +39 011 555 7788<br>Email: info@sportivanetwork.com</p>
                    <p class="footer-p1">Aperti tutti i giorni: 08:00 - 24:00</p>
                </div>
            </div>
            <div class="footer-bottom">
                <div>&copy; 2026 Sportiva Network S.r.l. | P.IVA 12345678901 | Tutti i diritti riservati.</div>
                <div><a href="#" class="footer-link">Privacy Policy</a> <a href="#" class="footer-link1">Safeguarding Policy</a></div>
            </div>
        </footer>

        <script src="js/tendina-login.js"></script>

    </body>
</html>

