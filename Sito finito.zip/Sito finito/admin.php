<?php
    session_start();

    // Controllo sicurezza: solo l'admin può accedere
    if (!isset($_SESSION['utente_loggato']) || $_SESSION['ruolo'] !== 'admin') {
        header("Location: login.php");
        exit();
    }

    // Connessione DB
    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "sportiva_network";
    $conn = new mysqli($host, $user, $password, $database);

    if($conn->connect_error){
        die("Errore connessione: " . $conn->connect_error);
    }

    // 2. LOGICA DI GESTIONE (AZIONI)
    $page = $_GET['page'] ?? 'home';
    $message = "";

    // Gestione Cancellazioni Universale
    if (isset($_GET['delete_id']) && isset($_GET['table']) && isset($_GET['pk'])) {
        $id = (int)$_GET['delete_id'];
        $table = $_GET['table'];
        $pk = $_GET['pk'];
        if ($conn->query("DELETE FROM $table WHERE $pk = $id")) {
            $message = "<div class='alert alert-danger'>Elemento rimosso con successo.</div>";
        }
    }

    // Gestione Inserimenti e Modifiche (Semplificata, vecchio stile)
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        
        // 1. SE HAI PREMUTO "AGGIUNGI ATTIVITÀ"
        if (isset($_POST['add_attivita'])) {
            $nome = $_POST['nome'];
            $cat = $_POST['cat'];
            $descrizione = $_POST['desc'];
            $inizio = $_POST['inizio'];
            $fine = $_POST['fine'];
            $nomeStruttura = $_POST['struttura'];
            $cognomeIstruttore = $_POST['istruttore'];
            
            $sql = "INSERT INTO attivita (nomeAttivita, categoria, descrizione, oraInizio, oraFine, idStruttura, idIstruttore) VALUES ('$nome', '$cat', '$descrizione', '$inizio', '$fine', 
                    (SELECT idStruttura FROM strutture WHERE nomeStruttura = '$nomeStruttura' LIMIT 1),
                    (SELECT idIstruttore FROM istruttori WHERE cognomeIstruttore = '$cognomeIstruttore' LIMIT 1)
                    )";
            // AGGIUNGIAMO QUESTO: Se c'è un errore, ci mostra a video la query esatta compilata
            if ($conn->query($sql)) {
                $message = "<div class='alert alert-success'>Attività aggiunta!</div>";
            } else {
                die("Rottura della query! Ecco cosa stavamo inviando al DB:<br><br><strong>" . $sql . "</strong><br><br>Errore del database: " . $conn->error);
            }   
        }
        // 2. ALTRIMENTI SE HAI PREMUTO "REGISTRA ISTRUTTORE"
        elseif (isset($_POST['add_istruttore'])) {
            $nome = $_POST['nome'];
            $cognome = $_POST['cognome'];
            $telefono = $_POST['telefono'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $cf = $_POST['cf'];
            $dataNascita = $_POST['nascita'];
            $dataRegistrazione = date("Y-m-d");
            
            $sql = "INSERT INTO istruttori (nomeIstruttore, cognomeIstruttore, dataNascitaIstruttore, telefonoIstruttore, emailIstruttore, password, codiceFiscaleIstruttore, dataRegistrazioneIstruttore) VALUES ('$nome', '$cognome', '$dataNascita', '$telefono', '$email', '$password', '$cf', '$dataRegistrazione')";
            if ($conn->query($sql)) {
                $message = "<div class='alert alert-success'>Istruttore registrato!</div>";
            } else {
                $message = "<div class='alert alert-danger'>Errore: " . $conn->error . "</div>";
            }
        }
        // 3. ALTRIMENTI SE HAI PREMUTO "AGGIUNGI OFFERTA"
        elseif (isset($_POST['modifica_offerta'])) {
            $nome = $_POST['nomeOfferta'];
            $tipo = $_POST['tipoOfferta'];
            $dataInizio = $_POST['dataInizioOfferta'];
            $dataFine = $_POST['dataFineOfferta'];

            $sql = "INSERT INTO offerte (nomeOfferta, tipoOfferta, dataInizioOfferta, dataFineOfferta) 
                    VALUES ('$nome', '$tipo', '$dataInizio', '$dataFine')";
            if ($conn->query($sql)) {
                $message = "<div class='alert alert-success'>Offerta aggiunta con successo!</div>";
            } else {
                $message = "<div class='alert alert-danger'>Errore: " . $conn->error . "</div>";
            }
        }
        // 4. ALTRIMENTI SE HAI PREMUTO "REGISTRA STRUTTURA"
        elseif (isset($_POST['modifica_struttura'])) {
            $nome = $_POST['nomeStruttura'];
            $capienza = $_POST['capienzaStruttura'];
            $tipologia = $_POST['tipologiaStruttura'];
            $nomeCentro = $_POST['nomeCentroSportivo'];

            $sql = "INSERT INTO strutture (nomeStruttura, capienzaStruttura, tipologiaStruttura, idCentroSportivo)
                    VALUES ('$nome', '$capienza', '$tipologia', 
                        (SELECT idCentroSportivo FROM centri_sportivi WHERE nomeCentroSportivo = '$nomeCentro')
                    )";

            if ($conn->query($sql)) {
                $message = "<div class='alert alert-success'>Struttura inserita con successo!</div>";
            } else {
                $message = "<div class='alert alert-danger'>Errore: " . $conn->error . "</div>";
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Area Amministratore - Sportiva Network</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="main-header">
        <nav class="navbar">
            <div class="logo-container">
                <a href="index.php"><img src="media/immagini/logo.png" alt="Logo" class="logo-img"></a>
            </div>
            <div class="user-dropdown">
                <button class="dropdown-btn">👤 <?php echo $_SESSION['ruolo']; ?></button>
                <div class="dropdown-content">
                    <a href="login.php?logout=true">Logout</a>
                </div>
            </div>
        </nav>
    </header>

    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-3 col-lg-2 sidebar">
                <h1 class="admin-title">Sezione amministrazione</h1>
                <ul class="menu-list">
                    <li><a href="?page=vis_attivita">• elenco attività sportive</a></li>
                    <li><a href="?page=istruttori">• elenco istruttori</a></li>
                    <li><a href="?page=utenti">• elenco utenti</a></li>
                    <li><a href="?page=strutture">• gestione campi/sale</a></li>
                    <li><a href="?page=offerte">• gestione offerte commerciali</a></li>
                    <li><a href="?page=prenotazioni">• gestione prenotazioni</a></li>
                    <li><a href="?page=istruttori">• inserimento/cancellazione istruttori</a></li>
                    <li><a href="?page=attivita">• inserimento/cancellazione attività</a></li>
                    <hr>
                    <li><a href="admin.php" class="text-muted small">Torna alla Home</a></li>
                </ul>
            </nav>

            <main class="col-md-9 col-lg-10 ms-sm-auto px-md-4 py-4">
                <?php echo $message; ?>

                <?php if ($page == 'home'): ?>
                    <div class="jumbotron">
                        <h2 class="display-4">Benvenuto, Admin</h2>
                        <p class="lead">Seleziona una voce dal menu a sinistra per gestire il network sportivo.</p>
                    </div>

                <?php elseif ($page == 'vis_attivita'): ?>
                    <h2>Gestione Attività</h2>
                    <table class="table table-hover bg-white shadow-sm">
                        <thead class="table-dark">
                            <tr><th>Nome</th><th>Categoria</th><th>Orario</th></tr>
                        </thead>
                        <tbody>
                            <?php $res = $conn->query("SELECT * FROM attivita"); 
                                while($row = $res->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['nomeAttivita'] ?></td>
                                <td><?= $row['categoria'] ?></td>
                                <td><?= $row['oraInizio'] ?> - <?= $row['oraFine'] ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>

                <?php elseif ($page == 'istruttori'): ?>
                    <h2>Gestione Istruttori</h2>
                    <table class="table table-hover bg-white shadow-sm">
                        <thead class="table-dark">
                            <tr><th>Nome</th><th>Cognome</th><th>Email</th><th>Azioni</th></tr>
                        </thead>
                        <tbody>
                            <?php $res = $conn->query("SELECT * FROM istruttori"); 
                                while($row = $res->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['nomeIstruttore'] ?></td>
                                <td><?= $row['cognomeIstruttore'] ?></td>
                                <td><?= $row['emailIstruttore'] ?></td>
                                <td><a href="?page=istruttori&delete_id=<?= $row['idIstruttore'] ?>&table=istruttori&pk=idIstruttore" class="btn btn-sm btn-outline-danger">Rimuovi</a></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <div class="card p-3 mt-4">
                        <h5>Nuovo Istruttore</h5>
                        <form method="POST" class="row g-2">
                            <div class="col-md-3"><input type="text" name="nome" placeholder="Nome" class="form-control" required></div>
                            <div class="col-md-3"><input type="text" name="cognome" placeholder="Cognome" class="form-control" required></div>
                            <div class="col-md-3"><input type="date" name="nascita" class="form-control" required></div>
                            <div class="col-md-3"><input type="email" name="email" placeholder="Email" class="form-control" required></div>
                            <div class="col-md-3"><input type="password" name="password" placeholder="password" class="form-control" required></div>
                            <div class="col-md-3"><input type="number" name="telefono" placeholder="telefono" class="form-control" required></div>
                            <div class="col-md-3"><input type="text" name="cf" placeholder="Codice Fiscale" class="form-control" required></div>
                            <div class="col-12"><button name="add_istruttore" type="submit" class="btn btn-success">Registra Istruttore</button></div>
                        </form>
                    </div>

                <?php elseif ($page == 'utenti'): ?>
                    <h2>Elenco Utenti Registrati</h2>
                    <table class="table bg-white shadow-sm">
                        <thead><tr><th>ID</th><th>Nome Cognome</th><th>Email</th><th>Data Reg.</th></tr></thead>
                        <tbody>
                            <?php $res = $conn->query("SELECT * FROM utenti"); 
                                while($row = $res->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['idUtente'] ?></td>
                                <td><?= $row['nomeUtente'] ?> <?= $row['cognomeUtente'] ?></td>
                                <td><?= $row['emailUtente'] ?></td>
                                <td><?= $row['dataRegistrazione'] ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>

                <?php elseif ($page == 'strutture'): ?>
                    <h2>Gestione Campi e Sale</h2>
                    <table class="table bg-white">
                        <thead><tr><th>Nome</th><th>Capienza</th><th>Tipologia</th><th>Centro Sportivo</th></tr></thead>
                        <tbody>
                            <?php $res = $conn->query("
                                SELECT strutture.*, centri_sportivi.nomeCentroSportivo
                                FROM strutture
                                JOIN centri_sportivi 
                                ON strutture.idCentroSportivo = centri_sportivi.idCentroSportivo
                            "); 
                                while($row = $res->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['nomeStruttura'] ?></td>
                                <td><?= $row['capienzaStruttura'] ?></td>
                                <td><?= $row['tipologiaStruttura'] ?></td>
                                <td><?= $row['nomeCentroSportivo'] ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <div class="card p-3 mt-4">
                        <h5>Nuova Struttura</h5>
                        <form method="POST" class="row g-2">
                            <div class="col-md-3"><input type="text" name="nomeStruttura" placeholder="Nome" class="form-control" required></div>
                            <div class="col-md-3"><input type="text" name="capienzaStruttura" placeholder="capienza" class="form-control" required></div>
                            <div class="col-md-3"><input type="text" name="tipologiaStruttura" placeholder="tipologia" class="form-control" required></div>
                            <div class="col-md-3"><input type="text" name="nomeCentroSportivo" placeholder="nome Centro Sportivo" class="form-control" required></div>
                            <div class="col-12"><button name="modifica_struttura" type="submit" class="btn btn-success">Registra Struttura</button></div>
                        </form>
                    </div>

                <?php elseif ($page == 'offerte'): ?>
                    <h2>Gestione Offerte</h2>
                    <table class="table bg-white">
                        <thead><tr><th>Nome</th><th>Tipo</th><th>Inizio</th><th>Fine</th></tr></thead>
                        <tbody>
                            <?php $res = $conn->query("SELECT * FROM offerte"); 
                                while($row = $res->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['nomeOfferta'] ?></td>
                                <td><?= $row['tipoOfferta'] ?></td>
                                <td><?= $row['dataInizioOfferta'] ?></td>
                                <td><?= $row['dataFineOfferta'] ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <div class="card p-3 mt-4">
                        <h5>Aggiungi Offerta</h5>
                        <form method="POST" class="row g-2">
                            <div class="col-md-3"><input type="text" name="nomeOfferta" placeholder="Nome" class="form-control" required></div>
                            <div class="col-md-3"><input type="text" name="tipoOfferta" placeholder="tipo" class="form-control" required></div>
                            <div class="col-md-2"><input type="date" name="dataInizioOfferta" class="form-control"></div>
                            <div class="col-md-2"><input type="date" name="dataFineOfferta" class="form-control"></div>
                            <div class="col-md-2"><button name="modifica_offerta" type="submit" class="btn btn-primary w-100">Aggiungi</button></div>
                        </form>
                    </div>

                <?php elseif ($page == 'prenotazioni'): ?>
                    <h2>Registro Prenotazioni</h2>
                    <table class="table bg-white">
                        <thead><tr><th>Data</th><th>Ora</th><th>Stato</th><th>Utente</th></tr></thead>
                        <tbody>
                            <?php $res = $conn->query("SELECT p.*, u.cognomeUtente FROM prenotazioni p JOIN utenti u ON p.idUtente = u.idUtente"); 
                                while($row = $res->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['dataPrenotazione'] ?></td>
                                <td><?= $row['oraPrenotazione'] ?></td>
                                <td><span class="badge bg-<?= ($row['statoPrenotazione']=='Confermata')?'success':'warning' ?>"><?= $row['statoPrenotazione'] ?></span></td>
                                <td><?= $row['cognomeUtente'] ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>

                <?php elseif ($page == 'attivita'): ?>
                    <h2>Gestione Attività</h2>
                    <table class="table table-hover bg-white shadow-sm">
                        <thead class="table-dark">
                            <tr><th>Nome</th><th>Categoria</th><th>Orario</th><th>Azioni</th></tr>
                        </thead>
                        <tbody>
                            <?php $res = $conn->query("SELECT * FROM attivita"); 
                                while($row = $res->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['nomeAttivita'] ?></td>
                                <td><?= $row['categoria'] ?></td>
                                <td><?= $row['oraInizio'] ?> - <?= $row['oraFine'] ?></td>
                                <td><a href="?page=attivita&delete_id=<?= $row['idAttivita'] ?>&table=attivita&pk=idAttivita" class="btn btn-sm btn-outline-danger">Cancella</a></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <div class="card p-3 mt-4">
                        <h5>Aggiungi Attività</h5>
                        <form method="POST" class="row g-2">
                            <div class="col-md-3"><input type="text" name="nome" placeholder="Nome" class="form-control" required></div>
                            <div class="col-md-3"><input type="text" name="cat" placeholder="Categoria" class="form-control" required></div>
                            <div class="col-md-3"><input type="text" name="desc" placeholder="descrizione" class="form-control" required></div>
                            <div class="col-md-2"><input type="time" name="inizio" class="form-control"></div>
                            <div class="col-md-2"><input type="time" name="fine" class="form-control"></div>
                            <div class="col-md-3"><input type="text" name="struttura" placeholder="struttura" class="form-control" required></div>
                            <div class="col-md-3"><input type="text" name="istruttore" placeholder="istruttore" class="form-control" required></div>
                            <div class="col-md-2"><button name="add_attivita" type="submit" class="btn btn-primary w-100">Aggiungi</button></div>
                        </form>
                    </div>
                <?php endif; ?>
            </main>
        </div>
    </div>

    <script src="js/tendina-login"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> 
</body> 
</html>