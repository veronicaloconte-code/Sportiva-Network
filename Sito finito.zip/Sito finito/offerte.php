<?php
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "sportiva_network";

    $conn = new mysqli($host, $user, $password, $database);

    if ($conn->connect_error) {
        die("Errore connessione: " . $conn->connect_error);
    }

    // 1. Inizializziamo la variabile booleana per il controllo nel codice HTML
    $utente_loggato = isset($_SESSION['utente_loggato']) && !empty($_SESSION['utente_loggato']);
    $nomeCompleto = "Utente";

    // 2. Se l'utente è loggato, recuperiamo i suoi dati in sicurezza
    if ($utente_loggato) {
        $email = $_SESSION['utente_loggato'];

        $queryUtente = "SELECT nomeUtente, cognomeUtente FROM utenti WHERE emailUtente = '$email'";
        $risultatoUtente = $conn->query($queryUtente);

        if (!$risultatoUtente) {
            die("Errore query: " . $conn->error);
        }

        if ($risultatoUtente->num_rows > 0) {
            $utente = $risultatoUtente->fetch_assoc();
            // CORREZIONE BUG: Uso delle chiavi corrette del database
            $nomeCompleto = $utente['nomeUtente'] . " " . $utente['cognomeUtente'];
        }
    }

    // 3. Esecuzione della query per mostrare le offerte
    $query = "SELECT idOfferta AS idAttivita, nomeOfferta AS nomeAttivita, tipoOfferta AS categoria, 'Offerta speciale' AS descrizione, '00:00:00' AS oraInizio, '00:00:00' AS oraFine FROM offerte";
    $result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="it">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Tariffe</title>
        <link rel="stylesheet" href="style.css">

    </head>

    <body>
        <!-- HEADER -->
        <header class="main-header">
            <nav class="navbar">
                <div class="logo-container">
                    <a href="#">
                        <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                    </a>
                </div>

                <ul class="nav-menu">
                    <?php if ($utente_loggato): ?>
                        <div>
                            <li class="nav-item"><a href="home page.php">Home</a></li>
                        </div>
                    <?php else: ?>
                        <li class="nav-item"><a href="index.html">Home</a></li>
                    <?php endif; ?>
                    <li class="nav-item"><a href="AreaSport.php">Area Sport</a></li>
                    <li class="nav-item"><a href="WellnessEHub.php">Wellness e Hub</a></li>
                    <li class="nav-item"><a href="PalaFamily.php">PalaFamily</a></li>
                    <li class="nav-item"><a href="BusinessECoworking.php">Business e Coworking</a></li>
                    <li class="nav-item"><a href="offerte.php">Tariffe</a></li>
                    <li class="nav-item"><a href="prenotaOnline.php" class="btn-prenota">Prenota Online</a></li>

                    <?php if ($utente_loggato): ?>
                        <div class="user-dropdown">
                            <button type="button" id="dropdownBtn" class="dropdown-btn">
                                👤 <?php echo htmlspecialchars($nomeCompleto); ?>
                            </button>
                            <div id="dropdownMenu" class="dropdown-content">
                                <a href="login.php?logout=true">Logout</a>
                            </div>
                        </div>
                    <?php else: ?>
                        <li class="nav-item"><a href="login.php" class="btn-accedi">Accedi</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </header>
        
        <script src="js/tendina-login.js"></script>

        <!-- OFFERTE -->

        <section class="offerte-container">

            <h1 class="offerte-titolo">Tariffe e Offerte</h1>
            <div class="offerte-grid">
                <?php
                    while($attivita = $result->fetch_assoc()){
                        $prezzo = rand(20,80);
                        $sconto = rand(10,40);
                        $prezzoScontato =$prezzo - ($prezzo * $sconto / 100);
                        echo "
                        <div class='offerta-card'>
                            <div class='offerta-header'>
                                <div class='offerta-nome'>".$attivita['nomeAttivita']."</div>
                                <div class='offerta-categoria'>".$attivita['categoria']."</div>
                            </div>

                            <div class='offerta-body'>
                                <div class='offerta-info'>
                                    <span class='offerta-label'>Orario:</span>
                                    ".$attivita['oraInizio']."-".$attivita['oraFine']."
                                </div>
                                <div class='offerta-info'>"
                                    .$attivita['descrizione']."
                                </div>
                                <div class='offerta-prezzo'>
                                    € ".number_format($prezzoScontato,2)."
                                </div>

                                <div class='offerta-prezzo-originale'>
                                    € ".$prezzo."
                                </div>

                                <div class='offerta-sconto'>
                                    -".$sconto."% OFF
                                </div>

                                <form action='abbonamento.php' method='POST'>
                                    <input type='hidden' name='idOfferta' value='".$attivita['idAttivita']."'>
                                    <input type='hidden' name='nomeAbbonamento' value='".$attivita['nomeAttivita']."'>
                                    <input type='hidden' name='tipoAbbonamento' value='".$attivita['categoria']."'>
                                    <button type='submit' class='offerta-bottone'> Acquista Offerta</button>
                                </form>

                            </div>

                        </div>

                        ";
                    }

                ?>

            </div>

        </section>

    </body>

</html>