<?php

    session_start();

    //CONNESSIONE DATABASE

    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "sportiva_network";

    $conn = new mysqli($host, $user, $password, $database);

    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }

    // ==================== LOGIN UTENTE NORMALE ====================
    if (isset($_POST['login'])) {

        $email = $_POST['email'];
        $password = $_POST['password'];

        // AMMINISTRATORE
        $queryIstr = "SELECT * FROM amministratori WHERE emailAmministratore = '$email' AND password = '$password'";
        $resultIstr = $conn->query($queryIstr);

        if ($resultIstr && $resultIstr->num_rows > 0) {
            $amministratore = $resultIstr->fetch_assoc();
            $_SESSION['utente_loggato'] = true;
            $_SESSION['ruolo'] = "admin";
            $_SESSION['email'] = $email;
            $_SESSION['idAmministratore'] = $amministratore['idAmministratore'];
            header("Location: admin.php");
            exit();
        }

        // ISTRUTTORE (mantieni se vuoi)
        $queryIstr = "SELECT * FROM istruttori WHERE emailIstruttore = '$email' AND password = '$password'";
        $resultIstr = $conn->query($queryIstr);

        if ($resultIstr && $resultIstr->num_rows > 0) {
            $istruttore = $resultIstr->fetch_assoc();
            $_SESSION['utente_loggato'] = true;
            $_SESSION['ruolo'] = "istruttore";
            $_SESSION['email'] = $email;
            $_SESSION['idIstruttore'] = $istruttore['idIstruttore'];
            header("Location: istruttori.php");
            exit();
        }

        // UTENTE NORMALE
        $query = "SELECT * FROM utenti WHERE emailUtente = '$email'";
        $result = $conn->query($query);

        if ($result && $result->num_rows > 0) {
            $utente = $result->fetch_assoc();

            if ($utente['password'] === $password) {
                $_SESSION['utente_loggato'] = true;
                $_SESSION['ruolo'] = "utente";
                $_SESSION['email'] = $email;
                $_SESSION['idUtente'] = $utente['idUtente'];

                // ==================== TRACCIAMENTO LOGIN ====================
                $idUtente = $utente['idUtente'];
                $dataOggi = date("Y-m-d");
                $queryLog = "INSERT INTO log_accessi (idUtente, dataLogin) VALUES ('$idUtente', '$dataOggi')";
                $conn->query($queryLog);

                header("Location: area_utenti.php");
                exit();
            }
        }

        $errore = "Credenziali non valide";
    
    }

    //LOGOUT

    if (isset($_GET['logout'])) {

        session_destroy();

        header("Location: login.php");

        exit();
    }

    //PRENOTAZIONE ATTIVITÀ

    if (isset($_POST['prenota'])) {

        if (!isset($_SESSION['utente_loggato'])) {

            header("Location: login.php?redirect=prenotaOnline.php");
            exit();
        }

        if ($_SESSION['ruolo'] != "utente") {

            $errorePrenotazione = "Solo gli utenti possono prenotare";

        } else {

            $idUtente = $_SESSION['idUtente'];

            $idAttivita = $_POST['idAttivita'];

            $nomePrenotazione = "Prenotazione Attività";

            $dataPrenotazione = date("Y-m-d");

            $oraPrenotazione = date("H:i:s");

            $stato = "Confermata";

            $presenza = 0;

            $query = "INSERT INTO prenotazioni(
                nomePrenotazione,
                dataPrenotazione,
                oraPrenotazione,
                statoPrenotazione,
                presenzaUtente,
                idAttivita,
                idUtente
            )
            VALUES
            (?, ?, ?, ?, ?, ?, ?)";

            $stmt = $conn->prepare($query);

            $stmt->bind_param("ssssiii", $nomePrenotazione, $dataPrenotazione, $oraPrenotazione, $stato, $presenza, $idAttivita, $idUtente);

            if ($stmt->execute()) {

                $successoPrenotazione = "Prenotazione effettuata";

            } else {

                $errorePrenotazione = "Errore prenotazione";
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="it">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Accesso</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body class="background">
        <header class="main-header">
            <nav class="navbar">
                <div class="logo-container">
                    <a href="#">
                        <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                    </a>
                </div>

                <ul class="nav-menu">
                    <li class="nav-item"><a href="index.html">Home Page</a></li>
                    <li class="nav-item"><a href="AreaSport.php">Area Sport</a></li>
                    <li class="nav-item"><a href="WellnessEHub.php">Wellness e Hub</a></li>
                    <li class="nav-item"><a href="PalaFamily.php">PalaFamily</a></li>
                    <li class="nav-item"><a href="BusinessECoworking.php">Business e Coworking</a></li>
                    <li class="nav-item"><a href="offerte.php">Tariffe</a></li>
                    <li class="nav-item"><a href="prenotaOnline.php" class="btn-prenota">Prenota Online</a></li>
                </ul>
            </nav>
        </header>

        <header class="spaziatura"></header>

        <div class="container">
            <?php
                /*Utente loggato*/

                if (isset($_SESSION['utente_loggato'])){
                    echo "<h1>Benvenuto " . $_SESSION['ruolo'] . "</h1>";

                    /* Admin*/
                    if ($_SESSION['ruolo'] == "admin") {
                        echo "<h2>Area Amministratore</h2>";
                        echo "
                        <form method='POST'>
                            <textarea
                            name='query'
                            placeholder='Inserisci query SQL'></textarea>

                            <button name='esegui_query'>
                                Esegui Query
                            </button>

                        </form>
                        ";


                        if (isset($_POST['esegui_query'])) {
                            $query = $_POST['query'];
                            if ($conn->query($query)) {
                                echo "<p class='successo'>
                                Query eseguita correttamente
                                </p>";
                            } else {
                                echo "<p class='errore'>
                                Errore query
                                </p>";
                            }
                        }
                    }

                    /*Istruttore*/

                    if ($_SESSION['ruolo'] == "istruttore") {
                        echo "<h2>Area Istruttore</h2>";
                        echo "
                        <ul class='area-istruttore'>
                            <li class='area'>Aggiungi corsi</li>
                            <li class='area'>Modifica orari</li>
                            <li class='area'>Controlla affluenza corsi</li>
                        </ul>
                        ";
                    }

                    /*Utente*/
                    if ($_SESSION['ruolo'] == "utente") {
                        echo "<h2>Area Utente</h2>";
                        if (isset($successoPrenotazione)) {
                            echo "<p class='successo'>$successoPrenotazione</p>";
                        }

                        if (isset($errorePrenotazione)) {
                            echo "<p class='errore'>$errorePrenotazione</p>";
                        }

                        /*Visualizzazione attività*/

                        $query = "SELECT * FROM attivita";

                        $result = $conn->query($query);
                        echo "<form method='POST'>";
                        echo "<select name='idAttivita' required>";

                        while ($attivita = $result->fetch_assoc()) {
                            echo "
                            <option value='" . $attivita['idAttivita'] . "'> " . $attivita['nomeAttivita'] . " </option> ";
                        }

                        echo "</select>";
                        echo "<button name='prenota'>Prenota Attività</button> ";
                        echo "</form>";
                    }

                    echo "
                    <a class='logout' href='login.php?logout=true'>Logout</a>";

                } else {

            ?>

            <h1>Login</h1>

            <?php

            if (isset($errore)) {
                echo "<p class='errore'>$errore</p>";
            }
            ?>

            <form method="POST">

                <label>Inserisci l'email</label>

                <input type="email" name="email" required>
                <label>Inserisci password</label>

                <input type="password" name="password" required>

                <button name="login">Accedi</button>
            </form>

            <br>

            <p>Registrati se non ti sei ancora registrato</p>
            <form action="registrazione.php" method="post">
                <input type="submit" value="Registrati" class="registrazione">
            </form>

            <?php } ?>

        </div>

        <header class="spaziatura"></header>

        <footer>
            <div class="footer-container">
                <div class="footer-col">
                    <div class="logo-container" style="margin-bottom: 20px;">
                        <a href="#">
                            <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                        </a>
                    </div>
                    <p class="generated-style-12">Il punto di incontro ideale per chi ama lo sport, valorizza il benessere, ottimizza il lavoro e protegge il tempo in famiglia.</p>
                </div>
                <div class="footer-col">
                    <h4>I 4 Quadranti</h4>
                    <ul>
                        <li><a href="VascaNuoto.php">Academy Nuoto</a></li>
                        <li><a href="PrenotaPadel.php">Padel e Tennis Eventi</a></li>
                        <li><a href="OrariPalestra.php">Preparazione Atletica</a></li>
                        <li><a href="IscriviSquadra.php">Scuola Calcio Giovani</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Lifestyle Servizi</h4>
                    <ul>
                        <li><a href="#">Centro Medico ed Estetico</a></li>
                        <li><a href="#">Coworking & Startup Lab</a></li>
                        <li><a href="#">Ristorante & Lounge Bar</a></li>
                        <li><a href="#">Feste PalaFamily</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Contatti e Orari</h4>
                    <p class="footer-p">Viale dello Sport, 100<br>10095 Grugliasco (TO)</p>
                    <p class="footer-p">Segreteria: +39 011 555 7788<br>Email: info@sportivanetwork.com</p>
                    <p class="footer-p1">Aperti tutti i giorni: 08:00 - 24:00</p>
                </div>
            </div>
            <div class="footer-bottom">
                <div>&copy; 2026 Sportiva Network S.r.l. | P.IVA 12345678901 | Tutti i diritti riservati.</div>
                <div><a href="#" class="footer-link">Privacy Policy</a> <a href="#" class="footer-link1">Safeguarding Policy</a></div>
            </div>
        </footer>
    </body>
</html>