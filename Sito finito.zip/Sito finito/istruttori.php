<?php
    session_start();

    // Controllo sicurezza: solo l'admin può accedere
    if (!isset($_SESSION['utente_loggato']) || $_SESSION['ruolo'] !== 'istruttore') {
        header("Location: login.php");
        exit();
    }

    // Connessione DB necessaria per la feature "Esegui Query"
    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "sportiva_network";
    $conn = new mysqli($host, $user, $password, $database);

    $email = $_SESSION['utente_loggato'];

    $queryIstruttore = "SELECT nomeIstruttore, cognomeIstruttore FROM istruttori WHERE emailIstruttore = '$email'";

    $risultatoIstruttore = $conn->query($queryIstruttore);

    if (!$risultatoIstruttore) {
        die("Errore query: " . $conn->error);
    }

    if ($risultatoIstruttore->num_rows > 0) {

        $utente = $risultatoIstruttore->fetch_assoc();

        $nomeCompleto = $utente['nome'] . " " . $utente['cognome'];

    } else {

        $nomeCompleto = "Istruttore";

    }

    /* DATI ISTRUTTORE */

    $email = $_SESSION['email'];

    $queryIstruttore = "SELECT * FROM istruttori 
    WHERE emailIstruttore = '$email'";

    $resultIstruttore = $conn->query($queryIstruttore);

    $istruttore = $resultIstruttore->fetch_assoc();

    $idIstruttore = $istruttore['idIstruttore'];

    /* MODIFICA ORARIO */

    if (isset($_POST['modifica_orario'])) {

        $idAttivita = $_POST['idAttivita'];

        $nuovoOrario = $_POST['nuovoOrario'];

        $queryUpdate = "UPDATE attivita
        SET orarioAttivita = '$nuovoOrario'
        WHERE idAttivita = '$idAttivita'";

        $conn->query($queryUpdate);
    }

    /* CORSI ISTRUTTORE */

    $queryCorsi = "SELECT * FROM attivita
    WHERE idIstruttore = '$idIstruttore'";

    $resultCorsi = $conn->query($queryCorsi);
?>

<!DOCTYPE html>
<html lang="it">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sportiva Network</title>
        <link rel="stylesheet" href="style.css">
        <style>
            table{
                text-align: center;
            }
        </style>
    </head>
    <body>
        <header class="main-header">
            <nav class="navbar">
                <div class="logo-container">
                    <a href="#">
                        <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                    </a>
                </div>

                <ul class="nav-menu">
                    <div class="user-dropdown">
                        <button type="button" id="dropdownBtn" class="dropdown-btn">
                            👤 <?php echo $nomeCompleto; ?>
                        </button>

                        <div id="dropdownMenu" class="dropdown-content">
                            <a href="login.php?logout=true">Logout</a>
                        </div>
                    </div>
                </ul>
            </nav>
        </header>
        <div class="spaziatura"></div>

        <div class="container">

            <h1>Area Istruttore</h1>

            <form method="POST">

                <label>Seleziona corso</label>

                <select name="idCorso">

                    <?php

                    while ($corso = $resultCorsi->fetch_assoc()) {

                        echo "
                        <option value='" . $corso['idAttivita'] . "'>
                            " . $corso['nomeAttivita'] . "
                        </option>
                        ";
                    }

                    ?>

                </select>

                <button name="visualizza">
                    Visualizza
                </button>

            </form>

            <br><br>

            <?php

                if (isset($_POST['visualizza'])) {

                    $idCorso = $_POST['idCorso'];

                    $queryTabella = "
                    SELECT 
                        attivita.nomeAttivita,
                        attivita.oraInizio,
                        attivita.oraFine,
                        strutture.nomeStruttura,
                        COUNT(prenotazioni.idPrenotazione) AS partecipanti
                    FROM attivita

                    LEFT JOIN strutture
                    ON attivita.idStruttura = strutture.idStruttura

                    LEFT JOIN prenotazioni
                    ON attivita.idAttivita = prenotazioni.idAttivita

                    WHERE attivita.idAttivita = '$idCorso'

                    GROUP BY attivita.idAttivita
                    ";

                    $resultTabella = $conn->query($queryTabella);

                    if ($resultTabella->num_rows > 0) {

                        echo "
                        <table border='1' cellpadding='10'>

                            <tr>
                                <th>Corso</th>
                                <th>Sala</th>
                                <th>Ora Inizio</th>
                                <th>Ora Fine</th>
                                <th>Partecipanti</th>
                                <th>Modifica Orario</th>
                            </tr>
                        ";

                        while ($riga = $resultTabella->fetch_assoc()) {

                            echo "
                            <tr>
                                <td>" . $riga['nomeAttivita'] . "</td>
                                <td>" . $riga['nomeStruttura'] . "</td>
                                <td>" . $riga['oraInizio'] . "</td>
                                <td>" . $riga['oraFine'] . "</td>
                                <td>" . $riga['partecipanti'] . "</td>
                                <td>
                                    <form method='POST'>
                                        <input type='hidden'
                                        name='idAttivita'
                                        value='$idCorso'>

                                        <input type='time'
                                        name='nuovoOrario'
                                        required>

                                        <button name='modifica_orario'>
                                            Modifica
                                        </button>

                                    </form>
                                </td>
                            </tr>
                            ";
                        }

                        echo "</table>";
                    }
                }
            ?>

        </div>

        <footer class="spaziatura"></footer>

        <footer>
            <div class="footer-container">
                <div class="footer-col">
                    <div class="logo-container" style="margin-bottom: 20px;">
                        <a href="#">
                            <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                        </a>
                    </div>
                    <p class="generated-style-12">Il punto di incontro ideale per chi ama lo sport, valorizza il benessere, ottimizza il lavoro e protegge il tempo in famiglia.</p>
                </div>
                <div class="footer-col">
                    <h4>I 4 Quadranti</h4>
                    <ul>
                        <li><a href="#">Academy Nuoto</a></li>
                        <li><a href="#">Padel e Tennis Eventi</a></li>
                        <li><a href="#">Preparazione Atletica</a></li>
                        <li><a href="#">Scuola Calcio Giovani</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Lifestyle Servizi</h4>
                    <ul>
                        <li><a href="#">Centro Medico ed Estetico</a></li>
                        <li><a href="#">Coworking & Startup Lab</a></li>
                        <li><a href="#">Ristorante & Lounge Bar</a></li>
                        <li><a href="#">Feste PalaFamily</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Contatti e Orari</h4>
                    <p class="footer-p">Viale dello Sport, 100<br>10095 Grugliasco (TO)</p>
                    <p class="footer-p">Segreteria: +39 011 555 7788<br>Email: info@sportivanetwork.com</p>
                    <p class="footer-p1">Aperti tutti i giorni: 08:00 - 24:00</p>
                </div>
            </div>
            <div class="footer-bottom">
                <div>&copy; 2026 Sportiva Network S.r.l. | P.IVA 12345678901 | Tutti i diritti riservati.</div>
                <div><a href="#" class="footer-link">Privacy Policy</a> <a href="#" class="footer-link1">Safeguarding Policy</a></div>
            </div>
        </footer>

        <script src="js/tendina-login.js"></script>

    </body>
</html>