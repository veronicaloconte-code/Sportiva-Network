<?php
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "sportiva_network";
    $conn = new mysqli($host, $user, $password, $database);

    // Controlliamo se l'utente è loggato
    $utente_loggato = isset($_SESSION['utente_loggato']);
    $nomeCompleto = "Utente";

    if ($utente_loggato) {
        $email = $_SESSION['utente_loggato'];
        $queryUtente = "SELECT nomeUtente, cognomeUtente FROM utenti WHERE emailUtente = '$email'";
        $risultatoUtente = $conn->query($queryUtente);

        if ($risultatoUtente && $risultatoUtente->num_rows > 0) {
            $utente = $risultatoUtente->fetch_assoc();
            // Correzione dei nomi dei campi del database:
            $nomeCompleto = $utente['nomeUtente'] . " " . $utente['cognomeUtente'];
        }
    }
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wellness e Hub</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!--Barra ricerca in alto-->
        <header class="main-header">
            <nav class="navbar">
                <div class="logo-container">
                    <a href="#">
                        <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                    </a>
                </div>

                <ul class="nav-menu">
                    <?php if ($utente_loggato): ?>
                        <div>
                            <li class="nav-item"><a href="home page.php">Home</a></li>
                        </div>
                    <?php else: ?>
                        <li class="nav-item"><a href="index.html">Home</a></li>
                    <?php endif; ?>
                    <li class="nav-item"><a href="AreaSport.php">Area Sport</a></li>
                    <li class="nav-item"><a href="WellnessEHub.php">Wellness e Hub</a></li>
                    <li class="nav-item"><a href="PalaFamily.php">PalaFamily</a></li>
                    <li class="nav-item"><a href="BusinessECoworking.php">Business e Coworking</a></li>
                    <li class="nav-item"><a href="offerte.php">Tariffe</a></li>
                    <li class="nav-item"><a href="prenotaOnline.php" class="btn-prenota">Prenota Online</a></li>

                    <?php if ($utente_loggato): ?>
                        <div class="user-dropdown">
                            <button type="button" id="dropdownBtn" class="dropdown-btn">
                                👤 <?php echo htmlspecialchars($nomeCompleto); ?>
                            </button>
                            <div id="dropdownMenu" class="dropdown-content">
                                <a href="login.php?logout=true">Logout</a>
                            </div>
                        </div>
                    <?php else: ?>
                        <li class="nav-item"><a href="login.php" class="btn-accedi">Accedi</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </header>
        
        <script src="js/tendina-login.js"></script>

        <header class="hero">
        <div class="hero-container">
            <div class="hero-content">
                <h1>Rigenera il Corpo, <span>Nutri la Mente</span></h1>
                <p class="hero-subtitle">Scopri i nostri centri specializzati: dalla riabilitazione medica all'estetica avanzata, passando per il nostro esclusivo Bistrot e lo store dedicato agli sportivi.</p>
            </div>
        </div>
        </header>

        <section class="lifestyle-section" style="margin-top: 20px;">
        <div class="lifestyle-container">
            <div class="lifestyle-content">
                <h2>I Servizi Hub & Medical</h2>
                <div class="lifestyle-features">
                    <div class="feature-item generated-style-2">
                        <h4>Centro Medico & Fisioterapia</h4>
                        <p>Specialisti in medicina dello sport, fisioterapisti e osteopati a tua disposizione per prevenzione, riabilitazione e massaggi decontratturanti post-gara.</p>
                    </div>
                    <div class="feature-item generated-style-2">
                        <h4>Estetica e Benessere</h4>
                        <p>Cabine per trattamenti viso/corpo, pressoterapia, solarium e area relax con sauna e bagno turco per rigenerarsi dopo l'allenamento.</p>
                    </div>
                    <div class="feature-item generated-style-3">
                        <h4>Pro Shop Sportivo</h4>
                        <p>Tutto l'abbigliamento e l'attrezzatura di cui hai bisogno: racchette da padel, scarpe tecniche, costumi e integratori delle migliori marche.</p>
                    </div>
                </div>
            </div>
            <div class="lifestyle-image generated-style-6">
                <h4 class="generated-style-7">Sportiva Network Bistrot</h4>
                <p class="generated-style-8">Non solo sport: il nostro Bistrot è il luogo perfetto per socializzare. Proponiamo colazioni energetiche, pokè bowl per pranzi sani, centrifughe fresche e cocktail curati per l'aperitivo serale.</p>
                <div class="generated-style-9" style="margin-top: 15px;">
                    <strong>Servizio ai tavoli e asporto disponibile.</strong><br>
                    Aperto dalle 07:30 alle 24:00.
                </div>
            </div>
        </div>
    </section>


    <!--Recapiti-->
    <footer>
        <div class="footer-container">
            <div class="footer-col">
                <div class="logo-container" style="margin-bottom: 20px;">
                    <a href="#">
                        <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                    </a>
                </div>
                <p class="generated-style-12">Il punto di incontro ideale per chi ama lo sport, valorizza il benessere, ottimizza il lavoro e protegge il tempo in famiglia.</p>
            </div>
            <div class="footer-col">
                <h4>I 4 Quadranti</h4>
                <ul>
                    <li><a href="VascaNuoto.php">Academy Nuoto</a></li>
                    <li><a href="PrenotaPadel.php">Padel e Tennis Eventi</a></li>
                    <li><a href="OrariPalestra.php">Preparazione Atletica</a></li>
                    <li><a href="IscriviSquadra.php">Scuola Calcio Giovani</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Lifestyle Servizi</h4>
                <ul>
                    <li><a href="#">Centro Medico ed Estetico</a></li>
                    <li><a href="#">Coworking & Startup Lab</a></li>
                    <li><a href="#">Ristorante & Lounge Bar</a></li>
                    <li><a href="#">Feste PalaFamily</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Contatti e Orari</h4>
                <p class="footer-p">Viale dello Sport, 100<br>10095 Grugliasco (TO)</p>
                <p class="footer-p">Segreteria: +39 011 555 7788<br>Email: info@sportivanetwork.com</p>
                <p class="footer-p1">Aperti tutti i giorni: 08:00 - 24:00</p>
            </div>
        </div>
        <div class="footer-bottom">
            <div>&copy; 2026 Sportiva Network S.r.l. | P.IVA 12345678901 | Tutti i diritti riservati.</div>
            <div><a href="#" class="footer-link">Privacy Policy</a> <a href="#" class="footer-link1">Safeguarding Policy</a></div>
        </div>
    </footer>
</body>
</html>