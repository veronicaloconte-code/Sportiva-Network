<?php

    session_start();

    //CONNESSIONE DATABASE

    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "sportiva_network";

    $conn = new mysqli($host, $user, $password, $database);

    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }

    //REGISTRAZIONE

    if (isset($_POST['registrati'])) {

        // Sanificazione dei dati inseriti dall'utente per evitare SQL Injection
        $codiceFiscale = $conn->real_escape_string($_POST['codice_fiscale']);
        $nome = $conn->real_escape_string($_POST['nome']);
        $cognome = $conn->real_escape_string($_POST['cognome']);
        $telefono = $conn->real_escape_string($_POST['telefono']);
        $email = $conn->real_escape_string($_POST['email_reg']);
        $password = $conn->real_escape_string($_POST['password_reg']);

        //CONTROLLO ETA'

        $dataNascitaInput = $_POST['data_nascita'];
        $natoIl = new DateTime($dataNascitaInput);
        $oggi = new DateTime();
        $differenza = $oggi->diff($natoIl);
        $eta = $differenza->y;

        if ($eta < 18) {
            $erroreRegistrazione = "Devi essere maggiorenne per registrarti come istruttore.";
        } else {
            $dataNascita = $conn->real_escape_string($dataNascitaInput);
            $dataRegistrazione = date("Y-m-d");

            //CONTROLLO EMAIL (Senza Prepared Statement)
            $check = "SELECT * FROM istruttori WHERE emailIstruttore = '$email'";
            $result = $conn->query($check);

            if ($result->num_rows > 0) {

                $erroreRegistrazione = "Email già registrata";

            } else {

                //INSERIMENTO DATABASE (Senza Prepared Statement)
                $insert = "INSERT INTO istruttori(
                    codiceFiscaleIstruttore,
                    nomeIstruttore,
                    cognomeIstruttore,
                    telefonoIstruttore,
                    emailIstruttore,
                    password,
                    dataNascitaIstruttore,
                    dataRegistrazioneIStruttore
                )
                VALUES
                ('$codiceFiscale', '$nome', '$cognome', '$telefono', '$email', '$password', '$dataNascita', '$dataRegistrazione')";

                if ($conn->query($insert)) {

                    $successo = "Registrazione completata";

                } else {

                    $erroreRegistrazione = "Errore registrazione: " . $conn->error;
                }
            }
        }
    }   
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registrati</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body class="background">
        <header class="main-header">
            <nav class="navbar">
                <div class="logo-container">
                    <a href="#">
                        <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                    </a>
                </div>

                <ul class="nav-menu">
                    <li class="nav-item"><a href="index.html">Home</a></li>
                    <li class="nav-item"><a href="AreaSport.php">Area Sport</a></li>
                    <li class="nav-item"><a href="WellnessEHub.php">Wellness e Hub</a></li>
                    <li class="nav-item"><a href="PalaFamily.php">PalaFamily</a></li>
                    <li class="nav-item"><a href="BusinessECoworking.php">Business e Coworking</a></li>
                    <li class="nav-item"><a href="offerte.php">Tariffe</a></li>
                    <li class="nav-item"><a href="prenotaOnline.php" class="btn-prenota">Prenota Online</a></li>
                    <li class="nav-item"><a href="login.php" class="btn-accedi">Accedi</a></li>
                </ul>
            </nav>
        </header>

        <header class="spaziatura"></header>

        <div class="container">
            <h2>Iscriviti</h2>

            <?php
                
                if (isset($erroreRegistrazione)) {
                    echo "<p class='errore'>$erroreRegistrazione</p>";
                }

                if (isset($successo)) {
                    echo "<p class='successo'>$successo</p>";
                }
            ?>

            <form method="POST">

                <label for="codice_fiscale">Inserisci il tuo codice fiscale</label>
                <input type="text" name="codice_fiscale" placeholder="Codice fiscale" required>

                <label for="codice_fiscale">Inserisci il tuo nome</label>
                <input type="text" name="nome" placeholder="Nome" required>

                <label for="codice_fiscale">Inserisci il tuo cognome</label>
                <input type="text" name="cognome" placeholder="Cognome" required>

                <label for="codice_fiscale">Inserisci la tua data di nascita</label>
                <input type="date" name="data_nascita" required>

                <label for="codice_fiscale">Inserisci il tuo numero di telefono</label>
                <input type="number" name="telefono" placeholder="Telefono" required>

                <label for="codice_fiscale">Inserisci la tua mail</label>
                <input type="email" name="email_reg" placeholder="Email" required>

                <label for="codice_fiscale">Inserisci la tua password</label>
                <input type="password" name="password_reg" placeholder="Password" required>

                <button name="registrati" class="registrazione">Iscriviti</button>
            </form>
        </div>

        <header class="spaziatura"></header>

        <footer>
            <div class="footer-container">
                <div class="footer-col">
                    <div class="logo-container" style="margin-bottom: 20px;">
                        <a href="#">
                            <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                        </a>
                    </div>
                    <p class="generated-style-12">Il punto di incontro ideale per chi ama lo sport, valorizza il benessere, ottimizza il lavoro e protegge il tempo in famiglia.</p>
                </div>
                <div class="footer-col">
                    <h4>I 4 Quadranti</h4>
                    <ul>
                        <li><a href="VascaNuoto.php">Academy Nuoto</a></li>
                        <li><a href="PrenotaPadel.php">Padel e Tennis Eventi</a></li>
                        <li><a href="OrariPalestra.php">Preparazione Atletica</a></li>
                        <li><a href="IscriviSquadra.php">Scuola Calcio Giovani</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Lifestyle Servizi</h4>
                    <ul>
                        <li><a href="#">Centro Medico ed Estetico</a></li>
                        <li><a href="#">Coworking & Startup Lab</a></li>
                        <li><a href="#">Ristorante & Lounge Bar</a></li>
                        <li><a href="#">Feste PalaFamily</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Contatti e Orari</h4>
                    <p class="footer-p">Viale dello Sport, 100<br>10095 Grugliasco (TO)</p>
                    <p class="footer-p">Segreteria: +39 011 555 7788<br>Email: info@sportivanetwork.com</p>
                    <p class="footer-p1">Aperti tutti i giorni: 08:00 - 24:00</p>
                </div>
            </div>
            <div class="footer-bottom">
                <div>&copy; 2026 Sportiva Network S.r.l. | P.IVA 12345678901 | Tutti i diritti riservati.</div>
                <div><a href="#" class="footer-link">Privacy Policy</a> <a href="#" class="footer-link1">Safeguarding Policy</a></div>
            </div>
        </footer>
    </body>
</html>