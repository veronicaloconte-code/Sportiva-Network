<?php
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "sportiva_network";
    $conn = new mysqli($host, $user, $password, $database);

    // Controlliamo se l'utente è loggato
    $utente_loggato = isset($_SESSION['utente_loggato']);
    $nomeCompleto = "Utente";

    if ($utente_loggato) {
        $email = $_SESSION['utente_loggato'];
        $queryUtente = "SELECT nomeUtente, cognomeUtente FROM utenti WHERE emailUtente = '$email'";
        $risultatoUtente = $conn->query($queryUtente);

        if ($risultatoUtente && $risultatoUtente->num_rows > 0) {
            $utente = $risultatoUtente->fetch_assoc();
            // Correzione dei nomi dei campi del database:
            $nomeCompleto = $utente['nomeUtente'] . " " . $utente['cognomeUtente'];
        }
    }
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iscrizione Tornei Calcio - Sportiva Network</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Semplice form pulito per l'iscrizione */
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            max-width: 600px;
            margin: 40px auto;
        }
        .form-group {
            margin-bottom: 20px;
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        .form-group input, .form-group select {
            padding: 12px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            font-size: 15px;
        }
    </style>
</head>
<body>
    <header class="main-header">
        <nav class="navbar">
            <div class="logo-container">
                <a href="#">
                    <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                </a>
            </div>

            <ul class="nav-menu">
                <?php if ($utente_loggato): ?>
                    <div>
                        <li class="nav-item"><a href="home page.php">Home</a></li>
                    </div>
                <?php else: ?>
                    <li class="nav-item"><a href="index.html">Home</a></li>
                <?php endif; ?>
                <li class="nav-item"><a href="AreaSport.php">Area Sport</a></li>
                <li class="nav-item"><a href="WellnessEHub.php">Wellness e Hub</a></li>
                <li class="nav-item"><a href="PalaFamily.php">PalaFamily</a></li>
                <li class="nav-item"><a href="BusinessECoworking.php">Business e Coworking</a></li>
                <li class="nav-item"><a href="offerte.php">Tariffe</a></li>
                <li class="nav-item"><a href="prenotaOnline.php" class="btn-prenota">Prenota Online</a></li>

                <?php if ($utente_loggato): ?>
                    <div class="user-dropdown">
                        <button type="button" id="dropdownBtn" class="dropdown-btn">
                            👤 <?php echo htmlspecialchars($nomeCompleto); ?>
                        </button>
                        <div id="dropdownMenu" class="dropdown-content">
                            <a href="login.php?logout=true">Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <li class="nav-item"><a href="login.php" class="btn-accedi">Accedi</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>
    
    <script src="js/tendina-login.js"></script>

    <header class="hero" style="background: linear-gradient(135deg, var(--red-logo), #991b1b);">
        <div class="hero-container">
            <div class="hero-content">
                <h1>Calcio a 5 e Tornei Aziendali</h1>
                <p class="hero-subtitle">Iscrivi il tuo team ai campionati stagionali o ai tornei veloci del weekend. Campi in erba sintetica certificata e arbitri ufficiali.</p>
            </div>
        </div>
    </header>

    <section style="padding: 0 20px;">
        <div class="form-container">
            <h2 style="margin-bottom: 15px; text-align: center;">Modulo di Registrazione Team</h2>
            <p style="margin-bottom: 25px; text-align: center; color: #64748b;">Compila i dettagli del capitano per bloccare lo slot della tua squadra nel prossimo torneo.</p>
            
            <form action="#" method="POST">
                <div class="form-group">
                    <label>Nome della Squadra</label>
                    <input type="text" placeholder="Es. FC Grugliasco Sport" required>
                </div>
                <div class="form-group">
                    <label>Nome e Cognome del Capitano</label>
                    <input type="text" placeholder="Es. Mario Rossi" required>
                </div>
                <div class="form-group">
                    <label>Recapito Telefonico</label>
                    <input type="tel" placeholder="Es. 333 1234567" required>
                </div>
                <div class="form-group">
                    <label>Scegli il Torneo</label>
                    <select>
                        <option>Campionato Invernale Calcio a 5 (Apertura Ottobre)</option>
                        <option>Torneo Lampo del Weekend (Sabato/Domenica)</option>
                        <option>Coppa Aziende / Business Cup</option>
                    </select>
                </div>
                <button type="submit" class="btn-accedi" style="width: 100%; border: none; cursor: pointer; padding: 14px;">Invia Richiesta d'Iscrizione</button>
            </form>
        </div>
    </section>

    <footer>
        <div class="footer-container">
            <div class="footer-col">
                <div class="logo-container" style="margin-bottom: 20px;">
                    <a href="#">
                        <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                    </a>
                </div>
                <p class="generated-style-12">Il punto di incontro ideale per chi ama lo sport, valorizza il benessere, ottimizza il lavoro e protegge il tempo in famiglia.</p>
            </div>
            <div class="footer-col">
                <h4>I 4 Quadranti</h4>
                <ul>
                    <li><a href="VascaNuoto.php">Academy Nuoto</a></li>
                    <li><a href="PrenotaPadel.php">Padel e Tennis Eventi</a></li>
                    <li><a href="OrariPalestra.php">Preparazione Atletica</a></li>
                    <li><a href="IscriviSquadra.php">Scuola Calcio Giovani</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Lifestyle Servizi</h4>
                <ul>
                    <li><a href="#">Centro Medico ed Estetico</a></li>
                    <li><a href="#">Coworking & Startup Lab</a></li>
                    <li><a href="#">Ristorante & Lounge Bar</a></li>
                    <li><a href="#">Feste PalaFamily</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Contatti e Orari</h4>
                <p class="footer-p">Viale dello Sport, 100<br>10095 Grugliasco (TO)</p>
                <p class="footer-p">Segreteria: +39 011 555 7788<br>Email: info@sportivanetwork.com</p>
                <p class="footer-p1">Aperti tutti i giorni: 08:00 - 24:00</p>
            </div>
        </div>
        <div class="footer-bottom">
            <div>&copy; 2026 Sportiva Network S.r.l. | P.IVA 12345678901 | Tutti i diritti riservati.</div>
            <div><a href="#" class="footer-link">Privacy Policy</a> <a href="#" class="footer-link1">Safeguarding Policy</a></div>
        </div>
    </footer>
</body>
</html>