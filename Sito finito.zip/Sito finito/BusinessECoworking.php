<?php
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "sportiva_network";
    $conn = new mysqli($host, $user, $password, $database);

    // Controlliamo se l'utente è loggato
    $utente_loggato = isset($_SESSION['utente_loggato']);
    $nomeCompleto = "Utente";

    if ($utente_loggato) {
        $email = $_SESSION['utente_loggato'];
        $queryUtente = "SELECT nomeUtente, cognomeUtente FROM utenti WHERE emailUtente = '$email'";
        $risultatoUtente = $conn->query($queryUtente);

        if ($risultatoUtente && $risultatoUtente->num_rows > 0) {
            $utente = $risultatoUtente->fetch_assoc();
            // Correzione dei nomi dei campi del database:
            $nomeCompleto = $utente['nomeUtente'] . " " . $utente['cognomeUtente'];
        }
    }
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Business e Coworking</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!--Barra ricerca in alto-->
        <header class="main-header">
            <nav class="navbar">
                <div class="logo-container">
                    <a href="#">
                        <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                    </a>
                </div>

                <ul class="nav-menu">
                    <?php if ($utente_loggato): ?>
                        <div>
                            <li class="nav-item"><a href="home page.php">Home</a></li>
                        </div>
                    <?php else: ?>
                        <li class="nav-item"><a href="index.html">Home</a></li>
                    <?php endif; ?>
                    <li class="nav-item"><a href="AreaSport.php">Area Sport</a></li>
                    <li class="nav-item"><a href="WellnessEHub.php">Wellness e Hub</a></li>
                    <li class="nav-item"><a href="PalaFamily.php">PalaFamily</a></li>
                    <li class="nav-item"><a href="BusinessECoworking.php">Business e Coworking</a></li>
                    <li class="nav-item"><a href="offerte.php">Tariffe</a></li>
                    <li class="nav-item"><a href="prenotaOnline.php" class="btn-prenota">Prenota Online</a></li>

                    <?php if ($utente_loggato): ?>
                        <div class="user-dropdown">
                            <button type="button" id="dropdownBtn" class="dropdown-btn">
                                👤 <?php echo htmlspecialchars($nomeCompleto); ?>
                            </button>
                            <div id="dropdownMenu" class="dropdown-content">
                                <a href="login.php?logout=true">Logout</a>
                            </div>
                        </div>
                    <?php else: ?>
                        <li class="nav-item"><a href="login.php" class="btn-accedi">Accedi</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </header>
        
        <script src="js/tendina-login.js"></script>


        <header class="hero" style="background-color: #f4f7f6;">
        <div class="hero-container">
            <div class="hero-content">
                <h1>Lavora, Connettiti, <span>Allenati</span></h1>
                <p class="hero-subtitle" style="color: #555;">Il primo Coworking integrato in un polo sportivo. Ottimizza il tuo tempo lavorando a pochi passi dal tuo campo da padel o dalla palestra, facendo networking con altri professionisti.</p>
                <br>
                <a href="prenotaOnline.php" class="btn-primary">Riserva la tua scrivania</a>
            </div>
        </div>
        </header>

        <section class="lifestyle-section">
        <div class="lifestyle-container">
            <div class="lifestyle-content" style="flex: 1;">
                <h2>I Nostri Spazi Business</h2>
                <p>Ambienti climatizzati, silenziosi e dotati di connessione Fibra Ottica ultra-veloce. Scegli la soluzione più adatta alle tue esigenze lavorative.</p>
                <br>
                <div class="lifestyle-features">
                    <div class="feature-item generated-style-4">
                        <h4>Postazioni in Open Space</h4>
                        <p>Scrivanie ampie in un ambiente condiviso e stimolante. Ideale per freelance e smart worker.</p>
                    </div>
                    <div class="feature-item generated-style-4">
                        <h4>Uffici Privati</h4>
                        <p>15 uffici indipendenti (da 2 a 6 postazioni), perfetti per startup e team di lavoro che necessitano di privacy.</p>
                    </div>
                    <div class="feature-item generated-style-4">
                        <h4>Sale Meeting & Formazione</h4>
                        <p>Sale riunioni attrezzate con schermi 4K, lavagne interattive e servizio coffee break su richiesta.</p>
                    </div>
                </div>
            </div>
        </div>
        </section>


        <!--Recapiti-->
        <footer>
            <div class="footer-container">
                <div class="footer-col">
                    <div class="logo-container" style="margin-bottom: 20px;">
                        <a href="#">
                            <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                        </a>
                    </div>
                    <p class="generated-style-12">Il punto di incontro ideale per chi ama lo sport, valorizza il benessere, ottimizza il lavoro e protegge il tempo in famiglia.</p>
                </div>
                <div class="footer-col">
                    <h4>I 4 Quadranti</h4>
                    <ul>
                        <li><a href="VascaNuoto.php">Academy Nuoto</a></li>
                        <li><a href="PrenotaPadel.php">Padel e Tennis Eventi</a></li>
                        <li><a href="OrariPalestra.php">Preparazione Atletica</a></li>
                        <li><a href="IscriviSquadra.php">Scuola Calcio Giovani</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Lifestyle Servizi</h4>
                    <ul>
                        <li><a href="#">Centro Medico ed Estetico</a></li>
                        <li><a href="#">Coworking & Startup Lab</a></li>
                        <li><a href="#">Ristorante & Lounge Bar</a></li>
                        <li><a href="#">Feste PalaFamily</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Contatti e Orari</h4>
                    <p class="footer-p">Viale dello Sport, 100<br>10095 Grugliasco (TO)</p>
                    <p class="footer-p">Segreteria: +39 011 555 7788<br>Email: info@sportivanetwork.com</p>
                    <p class="footer-p1">Aperti tutti i giorni: 08:00 - 24:00</p>
                </div>
            </div>
            <div class="footer-bottom">
                <div>&copy; 2026 Sportiva Network S.r.l. | P.IVA 12345678901 | Tutti i diritti riservati.</div>
                <div><a href="#" class="footer-link">Privacy Policy</a> <a href="#" class="footer-link1">Safeguarding Policy</a></div>
            </div>
        </footer>
</body>
</html>