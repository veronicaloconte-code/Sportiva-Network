<?php
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "sportiva_network";
    $conn = new mysqli($host, $user, $password, $database);

    // Controlliamo se l'utente è loggato
    $utente_loggato = isset($_SESSION['utente_loggato']);
    $nomeCompleto = "Utente";

    if ($utente_loggato) {
        $email = $_SESSION['utente_loggato'];
        $queryUtente = "SELECT nomeUtente, cognomeUtente FROM utenti WHERE emailUtente = '$email'";
        $risultatoUtente = $conn->query($queryUtente);

        if ($risultatoUtente && $risultatoUtente->num_rows > 0) {
            $utente = $risultatoUtente->fetch_assoc();
            // Correzione dei nomi dei campi del database:
            $nomeCompleto = $utente['nomeUtente'] . " " . $utente['cognomeUtente'];
        }
    }
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orari Corsi Fitness - Sportiva Network</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Stile semplice aggiunto localmente solo per impaginare bene la tabella degli orari */
        .orari-table {
            width: 100%;
            border-collapse: collapse;
            margin: 30px 0;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }
        .orari-table th, .orari-table td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #e2e8f0;
        }
        .orari-table th {
            background-color: var(--orange-logo);
            color: white;
            font-weight: 600;
        }
        .orari-table tr:hover { background-color: #f8fafc; }
    </style>
</head>
<body>
    <header class="main-header">
        <nav class="navbar">
            <div class="logo-container">
                <a href="#">
                    <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                </a>
            </div>

            <ul class="nav-menu">
                <?php if ($utente_loggato): ?>
                    <div>
                        <li class="nav-item"><a href="home page.php">Home</a></li>
                    </div>
                <?php else: ?>
                    <li class="nav-item"><a href="index.html">Home</a></li>
                <?php endif; ?>
                <li class="nav-item"><a href="AreaSport.php">Area Sport</a></li>
                <li class="nav-item"><a href="WellnessEHub.php">Wellness e Hub</a></li>
                <li class="nav-item"><a href="PalaFamily.php">PalaFamily</a></li>
                <li class="nav-item"><a href="BusinessECoworking.php">Business e Coworking</a></li>
                <li class="nav-item"><a href="offerte.php">Tariffe</a></li>
                <li class="nav-item"><a href="prenotaOnline.php" class="btn-prenota">Prenota Online</a></li>

                <?php if ($utente_loggato): ?>
                    <div class="user-dropdown">
                        <button type="button" id="dropdownBtn" class="dropdown-btn">
                            👤 <?php echo htmlspecialchars($nomeCompleto); ?>
                        </button>
                        <div id="dropdownMenu" class="dropdown-content">
                            <a href="login.php?logout=true">Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <li class="nav-item"><a href="login.php" class="btn-accedi">Accedi</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>
    
    <script src="js/tendina-login.js"></script>

    <header class="hero" style="background: linear-gradient(135deg, var(--orange-logo), #c2410c);">
        <div class="hero-container">
            <div class="hero-content">
                <h1>Palestra e Functional Training</h1>
                <p class="hero-subtitle">Pianifica la tua settimana di benessere.
                    Scopri l'orario dei nostri corsi di gruppo
                    guidati dai migliori trainer del settore.
                </p>
            </div>
        </div>

    </header>

    <section style="max-width: 1000px; margin: 40px auto; padding: 0 20px;">
        <h2>Palinsesto Corsi Settimanali</h2>
        <p>I corsi sono inclusi negli abbonamenti Full e Open. È richiesta la prenotazione tramite App per garantire il posto.</p>
        
        <table class="orari-table">
            <thead>
                <tr>
                    <th>Fascia Oraria</th>
                    <th>Lunedì / Mercoledì</th>
                    <th>Martedì / Giovedì</th>
                    <th>Venerdì</th>
                    <th>Sabato</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong>09:00 - 10:00</strong></td>
                    <td style="color: var(--blue-logo); font-weight: 600;">Pilates Matwork</td>
                    <td style="color: var(--green-logo); font-weight: 600;">Yoga Flex</td>
                    <td style="color: var(--blue-logo); font-weight: 600;">Pilates Matwork</td>
                    <td style="color: var(--orange-logo); font-weight: 600;">Risveglio Muscolare</td>
                </tr>
                <tr>
                    <td><strong>13:00 - 14:00</strong></td>
                    <td style="color: var(--red-logo); font-weight: 600;">Functional Cross</td>
                    <td style="color: var(--orange-logo); font-weight: 600;">TRX Suspension</td>
                    <td style="color: var(--red-logo); font-weight: 600;">Functional Cross</td>
                    <td style="color: #6366f1; font-weight: 600;">Calisthenics Light</td>
                </tr>
                <tr>
                    <td><strong>18:30 - 19:30</strong></td>
                    <td style="color: var(--orange-logo); font-weight: 600;">Spinning & Cardio</td>
                    <td style="color: var(--red-logo); font-weight: 600;">Cross Training Arena</td>
                    <td style="color: var(--orange-logo); font-weight: 600;">Zumba Fitness</td>
                    <td style="color: #64748b;">Sala Pesi Libera</td>
                </tr>
                <tr>
                    <td><strong>19:30 - 20:30</strong></td>
                    <td style="color: var(--red-logo); font-weight: 600;">Cross Training Arena</td>
                    <td style="color: var(--green-logo); font-weight: 600;">Power Yoga</td>
                    <td style="color: var(--red-logo); font-weight: 600;">Circuit Training</td>
                    <td style="color: #64748b;">Chiusura Corsi</td>
                </tr>
            </tbody>
        </table>
    </section>

    <footer>
        <div class="footer-container">
            <div class="footer-col">
                <div class="logo-container" style="margin-bottom: 20px;">
                    <a href="#">
                        <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                    </a>
                </div>
                <p class="generated-style-12">Il punto di incontro ideale per chi ama lo sport, valorizza il benessere, ottimizza il lavoro e protegge il tempo in famiglia.</p>
            </div>
            <div class="footer-col">
                <h4>I 4 Quadranti</h4>
                <ul>
                    <li><a href="VascaNuoto.php">Academy Nuoto</a></li>
                    <li><a href="PrenotaPadel.php">Padel e Tennis Eventi</a></li>
                    <li><a href="OrariPalestra.php">Preparazione Atletica</a></li>
                    <li><a href="IscriviSquadra.php">Scuola Calcio Giovani</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Lifestyle Servizi</h4>
                <ul>
                    <li><a href="#">Centro Medico ed Estetico</a></li>
                    <li><a href="#">Coworking & Startup Lab</a></li>
                    <li><a href="#">Ristorante & Lounge Bar</a></li>
                    <li><a href="#">Feste PalaFamily</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Contatti e Orari</h4>
                <p class="footer-p">Viale dello Sport, 100<br>10095 Grugliasco (TO)</p>
                <p class="footer-p">Segreteria: +39 011 555 7788<br>Email: info@sportivanetwork.com</p>
                <p class="footer-p1">Aperti tutti i giorni: 08:00 - 24:00</p>
            </div>
        </div>
        <div class="footer-bottom">
            <div>&copy; 2026 Sportiva Network S.r.l. | P.IVA 12345678901 | Tutti i diritti riservati.</div>
            <div><a href="#" class="footer-link">Privacy Policy</a> <a href="#" class="footer-link1">Safeguarding Policy</a></div>
        </div>
    </footer>
</body>
</html>