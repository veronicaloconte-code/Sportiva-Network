<?php
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "sportiva_network";
    $conn = new mysqli($host, $user, $password, $database);

    // Controlliamo se l'utente è loggato
    $utente_loggato = isset($_SESSION['utente_loggato']);
    $nomeCompleto = "Utente";

    if ($utente_loggato) {
        $email = $_SESSION['utente_loggato'];
        $queryUtente = "SELECT nomeUtente, cognomeUtente FROM utenti WHERE emailUtente = '$email'";
        $risultatoUtente = $conn->query($queryUtente);

        if ($risultatoUtente && $risultatoUtente->num_rows > 0) {
            $utente = $risultatoUtente->fetch_assoc();
            // Correzione dei nomi dei campi del database:
            $nomeCompleto = $utente['nomeUtente'] . " " . $utente['cognomeUtente'];
        }
    }
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prenota Campo - Sportiva Network</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="main-header">
        <nav class="navbar">
            <div class="logo-container">
                <a href="#">
                    <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                </a>
            </div>

            <ul class="nav-menu">
                <?php if ($utente_loggato): ?>
                    <div>
                        <li class="nav-item"><a href="home page.php">Home</a></li>
                    </div>
                <?php else: ?>
                    <li class="nav-item"><a href="index.html">Home</a></li>
                <?php endif; ?>
                <li class="nav-item"><a href="AreaSport.php">Area Sport</a></li>
                <li class="nav-item"><a href="WellnessEHub.php">Wellness e Hub</a></li>
                <li class="nav-item"><a href="PalaFamily.php">PalaFamily</a></li>
                <li class="nav-item"><a href="BusinessECoworking.php">Business e Coworking</a></li>
                <li class="nav-item"><a href="offerte.php">Tariffe</a></li>
                <li class="nav-item"><a href="prenotaOnline.php" class="btn-prenota">Prenota Online</a></li>

                <?php if ($utente_loggato): ?>
                    <div class="user-dropdown">
                        <button type="button" id="dropdownBtn" class="dropdown-btn">
                            👤 <?php echo htmlspecialchars($nomeCompleto); ?>
                        </button>
                        <div id="dropdownMenu" class="dropdown-content">
                            <a href="login.php?logout=true">Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <li class="nav-item"><a href="login.php" class="btn-accedi">Accedi</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>
    
    <script src="js/tendina-login.js"></script>

    <header class="hero" style="background: linear-gradient(135deg, var(--green-logo), #15803d);">
        <div class="hero-container">
            <div class="hero-content">
                <h1>Padel e Tennis Arena</h1>
                <p class="hero-subtitle">Scendi in campo nelle nostre strutture panoramiche indoor e outdoor. Seleziona l'orario che preferisci e sfida i tuoi amici.</p>
            </div>
        </div>
    </header>

    <div class="hub-intro" style="margin-top: 50px;">
        <h2>Prenotazione Rapida Campi</h2>
        <p>Seleziona la disciplina e verifica la disponibilità in tempo reale dei nostri 14 campi totali.</p>
    </div>

    <section class="sports-grid" style="margin-bottom: 50px; max-width: 800px; margin-left: auto; margin-right: auto;">
        <div class="sport-card card-green" style="text-align: center;">
            <h3>Seleziona la data</h3>
            <p style="margin-bottom: 15px;">Campi dotati di illuminazione LED e vetri panoramici.</p>
            <form style="display: flex; flex-direction: column; gap: 15px; align-items: center;">
                <input type="date" style="padding: 10px; border-radius: 8px; border: 1px solid #ccc; width: 80%;">
                <select style="padding: 10px; border-radius: 8px; border: 1px solid #ccc; width: 80%;">
                    <option>Padel Indoor (60 min)</option>
                    <option>Padel Outdoor (60 min)</option>
                    <option>Tennis Terra Rossa (60 min)</option>
                    <option>Tennis Play-Flex Indoor (60 min)</option>
                </select>
                <a href="prenotaOnline.php" class="btn-prenota" style="display: inline-block; text-align: center; margin-top: 10px;">Verifica Orari su App</a>
            </form>
        </div>
    </section>

    <footer>
        <div class="footer-container">
            <div class="footer-col">
                <div class="logo-container" style="margin-bottom: 20px;">
                    <a href="#">
                        <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                    </a>
                </div>
                <p class="generated-style-12">Il punto di incontro ideale per chi ama lo sport, valorizza il benessere, ottimizza il lavoro e protegge il tempo in famiglia.</p>
            </div>
            <div class="footer-col">
                <h4>I 4 Quadranti</h4>
                <ul>
                    <li><a href="VascaNuoto.php">Academy Nuoto</a></li>
                    <li><a href="PrenotaPadel.php">Padel e Tennis Eventi</a></li>
                    <li><a href="OrariPalestra.php">Preparazione Atletica</a></li>
                    <li><a href="IscriviSquadra.php">Scuola Calcio Giovani</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Lifestyle Servizi</h4>
                <ul>
                    <li><a href="#">Centro Medico ed Estetico</a></li>
                    <li><a href="#">Coworking & Startup Lab</a></li>
                    <li><a href="#">Ristorante & Lounge Bar</a></li>
                    <li><a href="#">Feste PalaFamily</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Contatti e Orari</h4>
                <p class="footer-p">Viale dello Sport, 100<br>10095 Grugliasco (TO)</p>
                <p class="footer-p">Segreteria: +39 011 555 7788<br>Email: info@sportivanetwork.com</p>
                <p class="footer-p1">Aperti tutti i giorni: 08:00 - 24:00</p>
            </div>
        </div>
        <div class="footer-bottom">
            <div>&copy; 2026 Sportiva Network S.r.l. | P.IVA 12345678901 | Tutti i diritti riservati.</div>
            <div><a href="#" class="footer-link">Privacy Policy</a> <a href="#" class="footer-link1">Safeguarding Policy</a></div>
        </div>
    </footer>
</body>
</html>