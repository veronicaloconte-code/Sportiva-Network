<?php
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "sportiva_network";
    $conn = new mysqli($host, $user, $password, $database);

    // Controlliamo se l'utente è loggato
    $utente_loggato = isset($_SESSION['utente_loggato']);
    $nomeCompleto = "Utente";

    if ($utente_loggato) {
        $email = $_SESSION['utente_loggato'];
        $queryUtente = "SELECT nomeUtente, cognomeUtente FROM utenti WHERE emailUtente = '$email'";
        $risultatoUtente = $conn->query($queryUtente);

        if ($risultatoUtente && $risultatoUtente->num_rows > 0) {
            $utente = $risultatoUtente->fetch_assoc();
            // Correzione dei nomi dei campi del database:
            $nomeCompleto = $utente['nomeUtente'] . " " . $utente['cognomeUtente'];
        }
    }
?>

<!DOCTYPE html>
<html lang="it">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sportiva Network</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>

        <!--Barra ricerca in alto-->
        <header class="main-header">
            <nav class="navbar">
                <div class="logo-container">
                    <a href="#">
                        <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                    </a>
                </div>

                <ul class="nav-menu">
                    <li class="nav-item"><a href="AreaSport.php">Area Sport</a></li>
                    <li class="nav-item"><a href="WellnessEHub.php">Wellness e Hub</a></li>
                    <li class="nav-item"><a href="PalaFamily.php">PalaFamily</a></li>
                    <li class="nav-item"><a href="BusinessECoworking.php">Business e Coworking</a></li>
                    <li class="nav-item"><a href="offerte.php">Tariffe</a></li>
                    <li class="nav-item"><a href="prenotaOnline.php" class="btn-prenota">Prenota Online</a></li>
                    <div class="user-dropdown">
                        <button type="button" id="dropdownBtn" class="dropdown-btn">
                            👤 <?php echo $nomeCompleto; ?>
                        </button>

                        <div id="dropdownMenu" class="dropdown-content">
                            <a href="login.php?logout=true">Logout</a>
                        </div>
                    </div>
                </ul>
            </nav>
        </header>

        <script src="js/tendina-login.js"></script>

        <!--Informazioni generali-->
        <header class="hero">
            <div class="hero-container">
                <div class="hero-content">
                    <h1>Il nuovo grande polo dedicato a <span>Sport, Benessere e Famiglia</span></h1>
                    <p class="hero-subtitle">Ispirato ai migliori modelli di aggregazione sportiva europei. Uno spazio unico di oltre 8.000 mq dove far convivere passioni, relax, relazioni e vita professionale.</p>
                    <div class="hero-buttons">
                        <a href="#prenota" class="btn-primary">Prenota un Campo</a>
                        <a href="#sport" class="btn-secondary">Scopri i Corsi</a>
                    </div>
                </div>
                <div class="hero-graphic" style="text-align: center;">
                    <div class="attivita">
                        <div><img src="media/immagini/nuotare.png" alt="nuotare" class="piscina"></div>
                        <div><img src="media/immagini/racchette.png" alt="padel" class="padel"></div>
                        <div><img src="media/immagini/spazio palestra.png" alt="palestra" class="palestra"></div>
                        <div><img src="media/immagini/campo calcio.png" alt="campo calcio" class="campoCalcio"></div>
                    </div>
                </div>
            </div>
        </header>

        <!--Servizi proposti-->
        <div class="hub-intro" id="sport">
            <h2>Un Hub, Infiniti Servizi</h2>
            <p>Come nel modello Palavillage, abbiamo progettato un villaggio dove ogni quadrante del nostro logo prende vita con strutture all'avanguardia, istruttori federali e soluzioni digitali integrate.</p>
        </div>

        <section class="sports-grid">
            <!-- Nuoto -->
            <div class="sport-card card-blue">
                <div class="sport-icon-box bg-blue"><img src="media/immagini/nuoto.png" alt="nuoto" class="nuoto"></div>
                <h3>Nuoto & Academy Acquatica</h3>
                <p>Piscina panoramica interna riscaldata. Corsi di nuoto per neonati, ragazzi e adulti. Area hydro-fitness e nuoto libero assistito 365 giorni all'anno.</p>
                <a href="VascaNuoto.php" class="sport-link link-blue">Scopri la vasca &rarr;</a>
            </div>

            <!-- Padel/Tennis -->
            <div class="sport-card card-green">
                <div class="sport-icon-box bg-green"><img src="media/immagini/tennis.png" alt="tennis" class="tennis"></div>
                <h3>Padel & Tennis Arena</h3>
                <p>10 campi da padel panoramici indoor di ultima generazione con telecamere integrate per rivedere i tuoi match e analizzare i colpi con i maestri.</p>
                <a href="PrenotaPadel.php" class="sport-link link-green">Prenota un campo &rarr;</a>
            </div>

            <!-- Fitness -->
            <div class="sport-card card-orange">
                <div class="sport-icon-box bg-orange"><img src="media/immagini/palestra.png" alt="fitnes" class="fitnes"></div>
                <h3>Palestra & Functional Training</h3>
                <p>Area fitness di 600 mq attrezzata con i più moderni macchinari connessi. Sale corsi per Pilates, Yoga, Functional Cross e preparazione atletica specifica.</p>
                <a href="OrariPalestra.php" class="sport-link link-orange">Orari dei corsi &rarr;</a>
            </div>

            <!-- Calcio -->
            <div class="sport-card card-red">
                <div class="sport-icon-box bg-red"><img src="media/immagini/calcio.png" alt="calcio" class="calcio"></div>
                <h3>Calcio a 5 & Tornei</h3>
                <p>Campi outdoor e indoor in erba sintetica di ultimissima generazione. Sede della nostra Academy giovanile e dei tornei aziendali del circuito Network.</p>
                <a href="IscriviSquadra.php" class="sport-link link-red">Iscrivi la squadra &rarr;</a>
            </div>
        </section>

        <!--Attività aggiuntive-->
        <section class="lifestyle-section" id="lifestyle">
            <div class="lifestyle-container">
                <div class="lifestyle-content">
                    <h2>Oltre lo Sport: Benessere, Family e Lavoro</h2>
                    <p>Sportiva Network non è solo una struttura sportiva, ma un ecosistema completo pensato per ottimizzare i tempi della tua giornata. Puoi allenarti mentre i tuoi figli si divertono o lavorare tra una partita e l'altra.</p>
                    <div class="lifestyle-features">
                        <div class="feature-item generated-style-2">
                            <h4>Area Wellness e Medical</h4>
                            <p>Studi di osteopatia, fisioterapia, massoterapia ed estetica avanzata per la cura del corpo.</p>
                        </div>
                        <div class="feature-item generated-style-3">
                            <h4>Hub Store Shopping</h4>
                            <p>Negozio tecnico specializzato sportswear, attrezzature padel/tennis e merchandising ufficiale.</p>
                        </div>
                        <div class="feature-item generated-style-4" id="business">
                            <h4>Coworking e Business</h4>
                            <p>15 uffici privati e postazioni condivise dotate di fibra ottica, sale meeting e servizi B2B.</p>
                        </div>
                        <div class="feature-item generated-style-5" id="family">
                            <h4>PalaFamily e Kids Area</h4>
                            <p>Spazio ludico-educativo con animatori professionisti per feste di compleanno e laboratori Lego®.</p>
                        </div>
                    </div>
                </div>
                <div class="lifestyle-image generated-style-6">
                    <h4 class="generated-style-7">Sportiva Network Bistrot</h4>
                    <p class="generated-style-8">Il cuore conviviale della struttura. Ristorante e Lounge Bar ideale per colazioni premium, pranzi di lavoro bilanciati ed esclusivi aperitivi post-partita.</p>
                    <div class="generated-style-9">
                        Aperto tutti i giorni: 08:00 - 24:00
                    </div>
                </div>
            </div>
        </section>

        <!--Prenotazione campi-->
        <section class="booking-section" id="prenota">
            <div class="booking-container">
                <div class="booking-info">
                    <h3>Prenotazione Rapida Campi e Attività</h3>
                    <p>Gestisci i tuoi match, invita gli amici, dividi la quota del campo o iscriviti ai tornei direttamente online o tramite la nostra App dedicata Sportiva Network.</p>
                    <div class="generated-style-10">
                        <strong>Matchmaking Intelligente:</strong> Non hai 4 giocatori per il padel? Trova giocatori del tuo stesso livello all'interno del network con un click.
                    </div>
                </div>
                
                <div class="booking-widget">
                    <div class="widget-tabs">
                        <button class="widget-tab tab-active">Padel e Tennis</button>
                        <button class="widget-tab">Calcio a 5</button>
                        <button class="widget-tab">Corsi Fitness</button>
                        <button class="widget-tab">Nuoto Libero</button>
                    </div>
                    <form onsubmit="event.preventDefault(); alert('Simulazione ricerca campi: Struttura pronta all integrazione API.')">
                        <div class="form-row">
                            <div class="form-group">
                                <label>Data</label>
                                <input type="date" value="2026-05-21">
                            </div>
                            <div class="form-group">
                                <label>Orario desiderato</label>
                                <select>
                                    <option>18:00 - 19:30</option>
                                    <option>19:30 - 21:00</option>
                                    <option>21:00 - 22:30</option>
                                    <option>Mattino (08:00 - 12:00)</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Tipologia Campo</label>
                                <select>
                                    <option>Indoor Panoramico (Telecamera)</option>
                                    <option>Outdoor Panoramico</option>
                                    <option>Campo Singolo</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Livello di Gioco</label>
                                <select>
                                    <option>Qualsiasi (Partita Privata)</option>
                                    <option>Principiante (1.0 - 2.5)</option>
                                    <option>Intermedio (2.5 - 4.0)</option>
                                    <option>Avanzato (4.0+)</option>
                                </select>
                            </div>
                        </div>
                        <button type="submit" class="btn-search-courts">Cerca Campi Disponibili</button>
                    </form>
                </div>
            </div>
        </section>

        <!--Orari e tariffe-->
        <section class="pricing-section" id="tariffe">
            <h2>Orari e Trasparenza Tariffe</h2>
            <table class="info-table">
                <thead>
                    <tr>
                        <th>Attività / Servizio</th>
                        <th>Fascia Oraria</th>
                        <th>Dettagli / Durata</th>
                        <th>Tariffa Socio</th>
                        <th>Prenotazione App</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>Padel Indoor Panoramico</strong></td>
                        <td>Fascia Alta (17:00 - 23:00)</td>
                        <td>90 Minuti (4 giocatori)</td>
                        <td>€ 12,00 <small>/ pers.</small></td>
                        <td><span class="badge-status badge-online">Disponibile</span></td>
                    </tr>
                    <tr>
                        <td><strong>Padel Outdoor Panoramico</strong></td>
                        <td>Tutti i giorni (08:00 - 23:00)</td>
                        <td>90 Minuti</td>
                        <td>€ 9,00 <small>/ pers.</small></td>
                        <td><span class="badge-status badge-online">Disponibile</span></td>
                    </tr>
                    <tr>
                        <td><strong>Ingresso Fitness & Palestra</strong></td>
                        <td>Open (Senza limiti)</td>
                        <td>Abbonamento Mensile Open</td>
                        <td>€ 59,00 <small>/ mese</small></td>
                        <td><span class="badge-status badge-online">Disponibile</span></td>
                    </tr>
                    <tr>
                        <td><strong>Scuola Nuoto Academy</strong></td>
                        <td>Corsi Bisettimanali</td>
                        <td>Trimestrale Ragazzi / Adulti</td>
                        <td>€ 240,00 <small>/ trim.</small></td>
                        <td><span class="badge-status badge-online">Iscrizioni Open</span></td>
                    </tr>
                    <tr>
                        <td><strong>Campo Calcio a 5 (Erba Sintetica)</strong></td>
                        <td>Serale (18:00 - 24:00)</td>
                        <td>60 Minuti (Luci incluse)</td>
                        <td>€ 70,00 <small>/ tot.</small></td>
                        <td><span class="badge-status badge-online">Disponibile</span></td>
                    </tr>
                    <tr>
                        <td><strong>Spazio Coworking Postazione</strong></td>
                        <td>Giornaliero (08:00 - 20:00)</td>
                        <td>Incluso Wifi & Accesso Gym</td>
                        <td>€ 25,00 <small>/ giorno</small></td>
                        <td><span class="badge-status badge-online">Disponibile</span></td>
                    </tr>
                </tbody>
            </table>
        </section>
        <script src="js/orari.js"></script>

        <section class="cta-section">
            <div class="cta-card">
                <h2>Prenota il tuo abbonamento</h2>
                <p>Accedi ai servizi premium di Sportiva Network.</p>
                <form action="abbonamento.php" method="post">
                    <input type="submit" value="Abbonati" class="abbonati">
                </form>
            </div>

            <div class="cta-card">
                <h2>Entra nel nostro team</h2>
                <p>Diventa istruttore ed entra nella community Sportiva.</p>
                <form action="iscrizione per istruttori.php" method="post">
                    <input type="submit" value="Iscriviti" class="iscrizione">
                </form>
            </div>

            <div class="cta-card">
                <h2>Storico prenotazioni</h2>
                <p>Controlla tutte le tue prenotazioni.</p>
                <form action="storico prenotazione.php" method="post">
                    <input type="submit" value="Visualizza" class="storico">
                </form>
            </div>

            <div class="cta-card">
                <h2>Frequenza Accessi</h2>
                <p>Controlla quante volte hai effettuato il login.</p>
                <form action="frequenza_accessi.php" method="get">
                    <input type="submit" value="Verifica" class="storico">
                </form>
            </div>
        </section>
        
        <footer class="spaziatura"></footer>

        <!--Recapiti-->
        <footer>
            <div class="footer-container">
                <div class="footer-col">
                    <div class="logo-container" style="margin-bottom: 20px;">
                        <a href="#">
                            <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                        </a>
                    </div>
                    <p class="generated-style-12">Il punto di incontro ideale per chi ama lo sport, valorizza il benessere, ottimizza il lavoro e protegge il tempo in famiglia.</p>
                </div>
                <div class="footer-col">
                    <h4>I 4 Quadranti</h4>
                    <ul>
                        <li><a href="VascaNuoto.php">Academy Nuoto</a></li>
                        <li><a href="PrenotaPadel.php">Padel e Tennis Eventi</a></li>
                        <li><a href="OrariPalestra.php">Preparazione Atletica</a></li>
                        <li><a href="IscriviSquadra.php">Scuola Calcio Giovani</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Lifestyle Servizi</h4>
                    <ul>
                        <li><a href="#">Centro Medico ed Estetico</a></li>
                        <li><a href="#">Coworking & Startup Lab</a></li>
                        <li><a href="#">Ristorante & Lounge Bar</a></li>
                        <li><a href="#">Feste PalaFamily</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Contatti e Orari</h4>
                    <p class="footer-p">Viale dello Sport, 100<br>10095 Grugliasco (TO)</p>
                    <p class="footer-p">Segreteria: +39 011 555 7788<br>Email: info@sportivanetwork.com</p>
                    <p class="footer-p1">Aperti tutti i giorni: 08:00 - 24:00</p>
                </div>
            </div>
            <div class="footer-bottom">
                <div>&copy; 2026 Sportiva Network S.r.l. | P.IVA 12345678901 | Tutti i diritti riservati.</div>
                <div><a href="#" class="footer-link">Privacy Policy</a> <a href="#" class="footer-link1">Safeguarding Policy</a></div>
            </div>
        </footer>
        <script src="js/orari.js"></script>
        <script src="js/tendina-login.js"></script>
    </body>
</html>