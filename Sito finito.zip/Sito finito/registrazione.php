<?php

    session_start();

    /* CONNESSIONE DATABASE */

    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "sportiva_network";

    $conn = new mysqli($host, $user, $password, $database);

    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }

    /* REGISTRAZIONE ISTRUTTORE */

    if (isset($_POST['registrati'])) {

        /* DATI FORM */

        $codiceFiscale = $_POST['codice_fiscale'];
        $nome = $_POST['nome'];
        $cognome = $_POST['cognome'];
        $dataNascita = $_POST['data_nascita'];
        $telefono = $_POST['telefono'];
        $email = $_POST['email_reg'];
        $password = $_POST['password_reg'];

        $dataRegistrazione = date("Y-m-d");

        $query = "INSERT INTO utenti (
            codiceFiscaleUtente,
            nomeUtente,
            cognomeUtente,
            dataNascita,
            telefonoUtente,
            emailUtente,
            password,
            dataRegistrazione
        )
        VALUES ('$codiceFiscale','$nome', '$cognome','$dataNascita','$telefono','$email','$password','$dataRegistrazione')";

        if ($conn->query($query)) {

            echo "Registrazione completata";

        } else {

            echo "Errore SQL: " . $conn->error;
        }
            
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registrati</title>
        <link rel="stylesheet" href="style.css">
        <style>
            .nav-menu {
                display: flex;
                align-items: center;
                gap: 20px; /* Riduce leggermente lo spazio tra una voce e l'altra per far stare tutto su una riga */
                list-style: none;
                margin: 0;
                padding: 0;
                flex-wrap: nowrap; /* Impedisce tassativamente agli elementi di andare a capo */
            }
        </style>
    </head>
    <body class="background">
        <header class="main-header">
            <nav class="navbar">
                <div class="logo-container">
                    <a href="#">
                        <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                    </a>
                </div>

                <ul class="nav-menu">
                    <li class="nav-item"><a href="index.html">Home</a></li>
                    <li class="nav-item"><a href="AreaSport.php">Area Sport</a></li>
                    <li class="nav-item"><a href="WellnessEHub.php">Wellness e Hub</a></li>
                    <li class="nav-item"><a href="PalaFamily.php">PalaFamily</a></li>
                    <li class="nav-item"><a href="BusinessECoworking.php">Business e Coworking</a></li>
                    <li class="nav-item"><a href="offerte.php">Tariffe</a></li>
                    <li class="nav-item"><a href="prenotaOnline.php" class="btn-prenota">Prenota Online</a></li>
                    <li class="nav-item"><a href="login.php" class="btn-accedi">Accedi</a></li>
                </ul>
            </nav>
        </header>

        <header class="spaziatura"></header>

        <div class="container">
            <h2>Registrati</h2>

            <?php

                if (isset($erroreRegistrazione)) {

                    echo "<p class='errore'>
                    $erroreRegistrazione
                    </p>";
                }

                if (isset($successo)) {

                    echo "<p class='successo'>$successo</p>";
                }
            ?>

            <form method="POST">

                <label for="codice_fiscale">Inserisci il tuo codice fiscale</label>
                <input type="text" name="codice_fiscale" placeholder="Codice fiscale" required>

                <label for="nome">Inserisci il tuo nome</label>
                <input type="text" name="nome" placeholder="Nome" required>

                <label for="cognome">Inserisci il tuo cognome</label>
                <input type="text" name="cognome" placeholder="Cognome" required>

                <label for="data_nascita">Inserisci la tua data di nascita</label>
                <input type="date" name="data_nascita" required>

                <label for="telefono">Inserisci il tuo numero di telefono</label>
                <input type="number" name="telefono" placeholder="Telefono" required>

                <label for="email_reg">Inserisci la tua mail</label>
                <input type="email" name="email_reg" placeholder="Email" required>

                <label for="password_reg">Inserisci la tua password</label>
                <input type="password" name="password_reg" placeholder="Password" required>

                <button name="registrati" class="registrazione">Registrati</button>
            </form>
        </div>

        <header class="spaziatura"></header>

        <footer>
            <div class="footer-container">
                <div class="footer-col">
                    <div class="logo-container" style="margin-bottom: 20px;">
                        <a href="#">
                            <img src="media/immagini/logo.png" alt="Sportiva Network Logo" class="logo-img">
                        </a>
                    </div>
                    <p class="generated-style-12">Il punto di incontro ideale per chi ama lo sport, valorizza il benessere, ottimizza il lavoro e protegge il tempo in famiglia.</p>
                </div>
                <div class="footer-col">
                    <h4>I 4 Quadranti</h4>
                    <ul>
                        <li><a href="VascaNuoto.php">Academy Nuoto</a></li>
                        <li><a href="PrenotaPadel.php">Padel e Tennis Eventi</a></li>
                        <li><a href="OrariPalestra.php">Preparazione Atletica</a></li>
                        <li><a href="IscriviSquadra.php">Scuola Calcio Giovani</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Lifestyle Servizi</h4>
                    <ul>
                        <li><a href="#">Centro Medico ed Estetico</a></li>
                        <li><a href="#">Coworking & Startup Lab</a></li>
                        <li><a href="#">Ristorante & Lounge Bar</a></li>
                        <li><a href="#">Feste PalaFamily</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Contatti e Orari</h4>
                    <p class="footer-p">Viale dello Sport, 100<br>10095 Grugliasco (TO)</p>
                    <p class="footer-p">Segreteria: +39 011 555 7788<br>Email: info@sportivanetwork.com</p>
                    <p class="footer-p1">Aperti tutti i giorni: 08:00 - 24:00</p>
                </div>
            </div>
            <div class="footer-bottom">
                <div>&copy; 2026 Sportiva Network S.r.l. | P.IVA 12345678901 | Tutti i diritti riservati.</div>
                <div><a href="#" class="footer-link">Privacy Policy</a> <a href="#" class="footer-link1">Safeguarding Policy</a></div>
            </div>
        </footer>
    </body>
</html>